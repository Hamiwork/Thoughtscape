import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { normalizeGeneratedGraph } from "../src/domain/generatedGraph.ts";
import { knowledgeReducer } from "../src/domain/relations.ts";
import { relationStances } from "../src/domain/exploration.ts";
import { mapEmphasis } from "../src/domain/emphasis.ts";
const fixture = () =>
  JSON.parse(
    readFileSync(
      new URL("./fixtures/generated-graph.json", import.meta.url),
      "utf8",
    ),
  );
const question = "大学应该允许学生使用 AI 写作吗？";
test("custom graph uses question-specific entities, provenance, perspectives, layout, and no invented evidence", () => {
  const data = normalizeGeneratedGraph(fixture(), question, "contract-test");
  assert.equal(data.issue.question, question);
  assert.equal(data.concepts.length, 12);
  assert.equal(data.stances.automation.label, "支持辅助写作");
  assert.ok(!JSON.stringify(data).includes("客服"));
  assert.deepEqual(data.sources, []);
  assert.deepEqual(data.evidence, []);
  assert.ok(
    data.relations.every(
      (r) =>
        r.verification === "ai-unverified" &&
        r.assessment.origin === "ai" &&
        !r.evidenceIds.length,
    ),
  );
  for (const [i, a] of data.concepts.entries())
    for (const b of data.concepts.slice(i + 1)) {
      assert.ok(
        Math.abs(a.position.x - b.position.x) >= 229 ||
          Math.abs(a.position.y - b.position.y) >= 114,
      );
    }
});
test("malformed, disconnected, duplicated and dangling model graphs cannot enter the UI", () => {
  for (const mutate of [
    (f: ReturnType<typeof fixture>) => {
      f.concepts[0].name = "这不是关键词而是一整段超出长度限制的解释文字";
    },
    (f: ReturnType<typeof fixture>) => {
      f.concepts[1].id = f.concepts[0].id;
    },
    (f: ReturnType<typeof fixture>) => {
      f.relations[0].targetId = "missing";
    },
    (f: ReturnType<typeof fixture>) => {
      f.relations[0].claimIds = ["missing"];
    },
    (f: ReturnType<typeof fixture>) => {
      f.concepts.push({ ...f.concepts[0], id: "isolated", name: "孤立节点" });
    },
    (f: ReturnType<typeof fixture>) => {
      f.relations.push({ ...f.relations[0] });
    },
  ]) {
    const f = fixture();
    mutate(f);
    assert.throws(() => normalizeGeneratedGraph(f, question, "test"));
  }
});
test("generated map undo and restore use its own baseline, and stance links use its own claims", () => {
  const data = normalizeGeneratedGraph(fixture(), question, "contract-test");
  const baseline = {
    concepts: data.concepts,
    relations: data.relations,
    history: [],
    notice: "",
  };
  const changed = knowledgeReducer(
    baseline,
    {
      type: "relation",
      id: "r01",
      kind: "uncertain",
      label: "待判断",
      reason: "还需要具体课程中的实际证据支持判断。",
      confirmed: false,
    },
    baseline,
  );
  assert.equal(changed.relations[0].assessment.kind, "uncertain");
  assert.deepEqual(
    knowledgeReducer(changed, { type: "undo" }, baseline).relations,
    baseline.relations,
  );
  assert.deepEqual(
    knowledgeReducer(changed, { type: "restore" }, baseline).concepts,
    baseline.concepts,
  );
  const index = Object.fromEntries(data.claims.map((c) => [c.id, c]));
  assert.deepEqual(relationStances(data.relations[0], index), ["automation"]);
  const emphasis = mapEmphasis(
    data.concepts,
    data.relations,
    "automation",
    null,
    new Set(),
    null,
    index,
  );
  assert.ok(emphasis.matchingEdges.has("r01"));
});
