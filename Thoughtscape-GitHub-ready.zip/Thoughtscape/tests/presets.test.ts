import test from "node:test";
import assert from "node:assert/strict";
import { presetQuestions, matchingPresets } from "../src/data/presets.ts";
import { knowledgeReducer } from "../src/domain/relations.ts";
import { relationStances } from "../src/domain/exploration.ts";
test("five independent preset questions have semantic networks, their own perspectives and honest provenance", () => {
  assert.equal(presetQuestions.length, 5);
  assert.equal(new Set(presetQuestions.map((p) => p.data.issue.name)).size, 5);
  for (const preset of presetQuestions) {
    const d = preset.data;
    assert.equal(d.mode, "demo");
    assert.equal(d.issue.question, preset.question);
    assert.ok(d.concepts.length >= 10 && d.relations.length >= 10);
    assert.match(d.dataNotice, /演示/);
    assert.ok(!d.generation);
    const ids = new Set(d.concepts.map((c) => c.id));
    const claims = Object.fromEntries(d.claims.map((c) => [c.id, c]));
    assert.ok(
      d.relations.every(
        (r) =>
          ids.has(r.sourceId) &&
          ids.has(r.targetId) &&
          r.assessment.reason.length >= 8 &&
          r.conditions.length &&
          r.uncertainty &&
          r.verification === "demo-hypothesis" &&
          r.assessment.origin === "demo",
      ),
    );
    assert.ok(d.relations.some((r) => relationStances(r, claims).length > 1));
    const baseline = {
      concepts: d.concepts,
      relations: d.relations,
      history: [],
      notice: "",
    };
    const changed = knowledgeReducer(
      baseline,
      {
        type: "relation",
        id: d.relations[0].id,
        kind: "uncertain",
        label: "待判断",
        reason: "这是对当前议题的独立判断，需要进一步核实。",
        confirmed: false,
      },
      baseline,
    );
    assert.equal(changed.relations[0].assessment.kind, "uncertain");
    assert.deepEqual(
      knowledgeReducer(changed, { type: "restore" }, baseline).relations,
      d.relations,
    );
    assert.deepEqual(
      knowledgeReducer(changed, { type: "undo" }, baseline).relations,
      d.relations,
    );
    if (preset.id !== "customer") {
      assert.ok(!JSON.stringify(d).includes("客服"));
      assert.deepEqual(d.evidence, []);
      assert.deepEqual(d.sources, []);
    }
  }
});
test("search resolves exact preset questions and unique topic keywords, unknown questions never use a fallback map", () => {
  for (const preset of presetQuestions)
    assert.deepEqual(
      matchingPresets(preset.question).map((p) => p.id),
      [preset.id],
    );
  for (const [query, id] of [
    ["远程办公是否有效？", "remote"],
    ["AI写作", "writing"],
    ["四天工作制", "workweek"],
    ["城市交通", "mobility"],
    ["客服", "customer"],
  ])
    assert.deepEqual(
      matchingPresets(query).map((p) => p.id),
      [id],
    );
  assert.deepEqual(matchingPresets("量子计算和传统计算的区别是什么？"), []);
  assert.equal(matchingPresets("").length, 5);
});
