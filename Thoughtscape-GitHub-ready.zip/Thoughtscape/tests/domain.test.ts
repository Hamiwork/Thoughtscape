import test from "node:test";
import { mapEmphasis } from "../src/domain/emphasis.ts";
import assert from "node:assert/strict";
import {
  concepts,
  claims,
  relations,
  evidence,
  sources,
  conceptById,
  evidenceById,
} from "../src/data/demo.ts";
import {
  neighborhood,
  neighborIds,
  isCrossStance,
  relationStances,
  stanceMatches,
} from "../src/domain/exploration.ts";
import {
  initialState,
  knowledgeReducer,
  validateAssessment,
} from "../src/domain/relations.ts";
import { mapNodes } from "../src/data/map.ts";
test("short concept network contains required keywords and no article-card content", () => {
  assert.equal(new Set(concepts.map((c) => c.id)).size, concepts.length);
  const required = [
    "标准查询",
    "物流查询",
    "退款纠纷",
    "复杂投诉",
    "情绪诉求",
    "自动处理",
    "响应速度",
    "等待时间",
    "处理成本",
    "一次解决率",
    "答案准确性",
    "用户信任",
    "用户控制感",
    "错误回答",
    "错误承诺",
    "人工介入",
    "转人工阈值",
    "上下文交接",
    "人工复核",
    "自动化边界",
    "高风险操作",
    "责任归属",
    "隐私风险",
    "处理失败",
    "任务复杂度",
    "服务容量",
    "错误风险",
  ];
  for (const name of required)
    assert.ok(
      concepts.some((c) => c.name === name),
      name,
    );
  for (const c of concepts) {
    assert.ok(c.name.length >= 2 && c.name.length <= 8);
    assert.ok(c.explanation);
    assert.ok(neighborIds(c.id, relations).length);
    for (const id of c.evidenceIds) assert.ok(evidenceById[id]);
  }
  assert.equal(mapNodes(concepts).length, concepts.length + 1);
});
test("all semantic relationships have independent rationale, conditions, traceable evidence and verification", () => {
  const kinds = new Set(relations.map((r) => r.assessment.kind));
  for (const kind of [
    "promotes",
    "suitable",
    "needs",
    "influences",
    "risk",
    "tradeoff",
    "conditional",
    "handoff",
  ])
    assert.ok(kinds.has(kind as never));
  for (const r of relations) {
    assert.ok(conceptById[r.sourceId]);
    assert.ok(conceptById[r.targetId]);
    assert.notEqual(r.sourceId, r.targetId);
    assert.ok(r.assessment.label);
    assert.ok(r.assessment.reason);
    assert.ok(r.conditions.length);
    assert.ok(r.uncertainty);
    assert.equal(r.verification, "demo-hypothesis");
    for (const id of r.evidenceIds) {
      const e = evidenceById[id];
      assert.ok(e);
      assert.ok(e.relationIds.includes(r.id));
      assert.ok(r.sourceIds.includes(e.sourceId));
    }
    for (const id of r.claimIds) assert.ok(claims.some((p) => p.id === id));
  }
});
test("perspectives overlap and stay independent from node and relation types", () => {
  for (const id of ["trust", "speed", "complexity"])
    assert.ok(conceptById[id].stanceIds.length > 1);
  const before = mapNodes(concepts).map((n) => ({
    id: n.id,
    position: n.position,
  }));
  for (const stance of ["automation", "challenge", "conditional"] as const) {
    assert.ok(concepts.some((c) => stanceMatches(c, stance)));
    assert.ok(concepts.some((c) => !stanceMatches(c, stance)));
    assert.deepEqual(
      mapNodes(concepts).map((n) => ({ id: n.id, position: n.position })),
      before,
    );
  }
  assert.ok(isCrossStance(relations.find((r) => r.id === "r31")!));
  assert.deepEqual(
    new Set(relationStances(relations.find((r) => r.id === "r31")!)),
    new Set(["automation", "challenge"]),
  );
});
test("progressive neighborhood expands without creating objects or losing cross-perspective paths", () => {
  const one = neighborhood("complaint", relations),
    two = neighborhood("complaint", relations, 2);
  assert.ok(two.size > one.size);
  assert.ok(one.has("human"));
  assert.ok(two.has("handoff"));
  assert.ok(neighborhood("complaint", relations, 3).has("efficiency"));
  for (const id of two) assert.ok(conceptById[id]);
  assert.equal(new Set(two).size, two.size);
});
test("relationship edits update only current judgment; pending and undo preserve original provenance", () => {
  const old = initialState.relations.find((r) => r.id === "r31")!;
  const next = knowledgeReducer(initialState, {
    type: "relation",
    id: "r31",
    kind: "uncertain",
    label: "待判断",
    reason: "还没有同场景的真实材料，不能确定影响方向。",
    confirmed: false,
  });
  const r = next.relations.find((r) => r.id === "r31")!;
  assert.equal(r.assessment.kind, "uncertain");
  assert.equal(r.assessment.label, "待判断");
  assert.equal(r.assessment.origin, "user");
  assert.equal(r.evidenceIds, old.evidenceIds);
  assert.equal(r.verification, "demo-hypothesis");
  assert.equal(old.assessment.kind, "conditional");
  assert.deepEqual(
    knowledgeReducer(next, { type: "undo" }).relations,
    initialState.relations,
  );
});
test("multi-stance edits update annotations with no topology or layout changes and share undo/reset", () => {
  const next = knowledgeReducer(initialState, {
    type: "stance",
    id: "trust",
    stanceIds: ["conditional"],
  });
  assert.deepEqual(next.concepts.find((c) => c.id === "trust")!.stanceIds, [
    "conditional",
  ]);
  assert.equal(next.relations, initialState.relations);
  assert.deepEqual(
    mapNodes(next.concepts).map((n) => n.position),
    mapNodes(initialState.concepts).map((n) => n.position),
  );
  assert.deepEqual(
    knowledgeReducer(next, { type: "undo" }).concepts,
    initialState.concepts,
  );
  assert.deepEqual(
    knowledgeReducer(next, { type: "restore" }).concepts,
    initialState.concepts,
  );
  const unclassified = knowledgeReducer(next, {
    type: "stance",
    id: "trust",
    stanceIds: [],
  });
  assert.deepEqual(
    unclassified.concepts.find((c) => c.id === "trust")!.stanceIds,
    [],
  );
});
test("unknown IDs, missing rationale, and unqualified conflicts cannot silently change graph", () => {
  assert.ok(
    validateAssessment(
      "conflict",
      "冲突",
      "同名概念不代表相同的场景和标准。",
      false,
    ),
  );
  assert.ok(
    validateAssessment(
      "uncertain",
      "",
      "证据不足，需要核实同场景材料。",
      false,
    ),
  );
  assert.ok(validateAssessment("conditional", "取决于", "太短", false));
  const bad = knowledgeReducer(initialState, {
    type: "relation",
    id: "r31",
    kind: "conflict",
    label: "冲突",
    reason: "目前还未确认相同场景中的结论。",
    confirmed: false,
  });
  assert.equal(bad.relations, initialState.relations);
  assert.equal(bad.history.length, 0);
  assert.equal(
    knowledgeReducer(initialState, {
      type: "stance",
      id: "missing",
      stanceIds: [],
    }),
    initialState,
  );
});
test("all materials disclose their constructed nature and support explicit judgments without fake citations", () => {
  for (const s of sources) {
    assert.equal(s.author, null);
    assert.equal(s.url, null);
    assert.equal(s.sourceType, "constructed-scenario");
    assert.equal(s.verification, "demo-hypothesis");
  }
  for (const e of evidence) {
    assert.equal(e.excerptType, "constructed");
    assert.ok(e.excerpt);
    assert.ok(e.judgment);
    assert.ok(e.limitation);
    assert.ok(e.conceptIds.length);
    assert.ok(e.relationIds.length);
    assert.ok(sources.some((s) => s.id === e.sourceId));
  }
});

test("transient keyword preview reveals its one-hop network across a stance filter without mutating data", () => {
  const before = JSON.stringify({ concepts, relations });
  const result = mapEmphasis(
    concepts,
    relations,
    "automation",
    null,
    new Set(),
    { type: "concept", id: "complaint" },
  );
  for (const id of ["complaint", "human", "refund", "complexity"])
    assert.equal(result.nodes.get(id)!.muted, false, id);
  assert.equal(result.nodes.get("complaint")!.previewed, true);
  assert.equal(result.nodes.get("privacy")!.muted, true);
  assert.equal(result.edges.get("r12")!.previewed, true);
  assert.equal(result.nodes.size, concepts.length + 1);
  assert.equal(result.edges.size, relations.length);
  assert.equal(JSON.stringify({ concepts, relations }), before);
});
test("leaving preview restores the locked exploration and its expanded scope", () => {
  const spotlight = neighborhood("complaint", relations, 2),
    locked = new Set(["complaint"]);
  const baseline = mapEmphasis(
    concepts,
    relations,
    "all",
    spotlight,
    locked,
    null,
  );
  const hover = mapEmphasis(concepts, relations, "all", spotlight, locked, {
    type: "concept",
    id: "trust",
  });
  assert.equal(hover.nodes.get("complaint")!.muted, false);
  assert.equal(hover.nodes.get("trust")!.previewed, true);
  const restored = mapEmphasis(
    concepts,
    relations,
    "all",
    spotlight,
    locked,
    null,
  );
  assert.deepEqual(restored, baseline);
});
test("perspective views preserve the issue and readable bridge endpoints", () => {
  const view = mapEmphasis(
    concepts,
    relations,
    "automation",
    null,
    new Set(),
    null,
  );
  assert.equal(view.nodes.get("issue")!.muted, false);
  assert.equal(view.nodes.get("boundary")!.bridge, true);
  assert.equal(view.nodes.get("boundary")!.muted, false);
  assert.equal(view.nodes.get("highrisk")!.muted, true);
  assert.equal(view.edges.get("r31")!.muted, false);
});
test("relation preview highlights its two endpoints and never loses a locked relation", () => {
  const view = mapEmphasis(concepts, relations, "all", null, new Set(), {
    type: "relation",
    id: "r31",
  });
  assert.equal(view.nodes.get("auto")!.muted, false);
  assert.equal(view.nodes.get("trust")!.muted, false);
  assert.equal(view.nodes.get("complaint")!.muted, true);
  assert.equal(view.edges.get("r31")!.previewed, true);
  const locked = mapEmphasis(
    concepts,
    relations,
    "all",
    new Set(["auto", "trust"]),
    new Set(["auto", "trust"]),
    { type: "concept", id: "complaint" },
  );
  assert.equal(locked.edges.get("r31")!.muted, false);
});
