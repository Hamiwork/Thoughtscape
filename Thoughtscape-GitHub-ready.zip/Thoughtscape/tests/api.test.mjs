import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { generateGraph, serviceConfig, ServiceError } from "../server/api.mjs";
const fixture = JSON.parse(
  readFileSync(
    new URL("./fixtures/generated-graph.json", import.meta.url),
    "utf8",
  ),
);
const config = serviceConfig({
  THOUGHTSCAPE_API_KEY: "test-secret-never-client",
  THOUGHTSCAPE_ENABLE_AI: "true",
  THOUGHTSCAPE_MODEL: "contract-test",
  THOUGHTSCAPE_BASE_URL: "https://api.openai.com/v1",
  THOUGHTSCAPE_ALLOW_PAID_API: "true",
});
test("API sends question and JSON contract only to configured provider, normalized data contains no credential", async () => {
  let sent;
  const data = await generateGraph("大学应该允许学生使用 AI 写作吗？", config, {
    fetchImpl: async (url, init) => {
      sent = { url, body: JSON.parse(init.body), headers: init.headers };
      return Response.json({
        choices: [
          {
            finish_reason: "stop",
            message: { content: JSON.stringify(fixture) },
          },
        ],
      });
    },
  });
  assert.equal(sent.url, "https://api.openai.com/v1/chat/completions");
  assert.match(sent.body.messages[1].content, /大学/);
  assert.equal(sent.body.response_format.type, "json_schema");
  assert.equal(sent.body.response_format.json_schema.strict, true);
  assert.ok(!JSON.stringify(data).includes(config.key));
  assert.equal(data.mode, "ai");
});
test("missing keys, provider refusals, truncation, invalid JSON, outages and HTTP errors never fall back to demo", async () => {
  await assert.rejects(
    generateGraph("问题", serviceConfig({ THOUGHTSCAPE_ENABLE_AI: "true" })),
    (e) => e.status === 503,
  );
  for (const body of [
    { choices: [{ finish_reason: "length", message: { content: "{}" } }] },
    { choices: [{ finish_reason: "stop", message: { content: "invalid" } }] },
    { choices: [{ finish_reason: "stop", message: { refusal: "no" } }] },
  ]) {
    await assert.rejects(
      generateGraph("问题", config, {
        fetchImpl: async () => Response.json(body),
      }),
      (e) => e instanceof ServiceError && e.status === 502,
    );
  }
  await assert.rejects(
    generateGraph("问题", config, {
      fetchImpl: async () => {
        throw new Error(config.key);
      },
    }),
    (e) => !e.message.includes(config.key) && e.status === 502,
  );
  await assert.rejects(
    generateGraph("问题", config, {
      fetchImpl: async () =>
        Response.json({ error: config.key }, { status: 401 }),
    }),
    (e) => !e.message.includes(config.key) && /API Key/.test(e.message),
  );
  assert.throws(() =>
    serviceConfig({ THOUGHTSCAPE_BASE_URL: "http://untrusted.example" }),
  );
  assert.equal(
    serviceConfig({ THOUGHTSCAPE_BASE_URL: "https://api.deepseek.com" })
      .tokenParam,
    "max_tokens",
  );
});

test("cloud billing is blocked by default even with credentials, and local requests never forward a cloud key", async () => {
  const blocked = serviceConfig({
    THOUGHTSCAPE_ENABLE_AI: "true",
    THOUGHTSCAPE_API_KEY: "never-send",
    THOUGHTSCAPE_MODEL: "test",
    THOUGHTSCAPE_BASE_URL: "https://api.deepseek.com",
  });
  let called = false;
  await assert.rejects(
    generateGraph("question", blocked, {
      fetchImpl: async () => {
        called = true;
      },
    }),
    (error) => error.status === 403,
  );
  assert.equal(called, false);
  const local = serviceConfig({
    THOUGHTSCAPE_ENABLE_AI: "true",
    THOUGHTSCAPE_API_KEY: "cloud-secret",
    THOUGHTSCAPE_MODEL: "local-test",
  });
  await generateGraph("question", local, {
    fetchImpl: async (_url, init) => {
      assert.equal(init.headers.Authorization, "Bearer ollama");
      return Response.json({
        choices: [
          {
            finish_reason: "stop",
            message: { content: JSON.stringify(fixture) },
          },
        ],
      });
    },
  });
});

test("optional AI integration is off by default even for fully configured local models", async () => {
  const disabled = serviceConfig({ THOUGHTSCAPE_MODEL: "local-test" });
  let called = false;
  await assert.rejects(
    generateGraph("question", disabled, {
      fetchImpl: async () => {
        called = true;
      },
    }),
    (e) => e.status === 403,
  );
  assert.equal(called, false);
});
