const str = { type: "string" };
const strings = { type: "array", items: str };
const stance = {
  type: "string",
  enum: ["automation", "challenge", "conditional"],
};
const object = (properties) => ({
  type: "object",
  properties,
  required: Object.keys(properties),
  additionalProperties: false,
});
export const graphSchema = object({
  title: str,
  summary: str,
  perspectives: object({ automation: str, challenge: str, conditional: str }),
  concepts: {
    type: "array",
    items: object({
      id: str,
      name: str,
      type: { type: "string", enum: ["concept", "condition"] },
      explanation: str,
      level: { type: "string", enum: ["primary", "secondary"] },
      stanceIds: { type: "array", items: stance },
    }),
  },
  claims: {
    type: "array",
    items: object({
      id: str,
      text: str,
      stanceId: stance,
      conceptIds: strings,
      conditions: strings,
    }),
  },
  relations: {
    type: "array",
    items: object({
      sourceId: str,
      targetId: str,
      kind: {
        type: "string",
        enum: [
          "promotes",
          "suitable",
          "needs",
          "influences",
          "risk",
          "tradeoff",
          "conditional",
          "handoff",
          "complement",
          "conflict",
          "uncertain",
        ],
      },
      label: str,
      reason: str,
      conditions: strings,
      uncertainty: str,
      claimIds: strings,
    }),
  },
});
