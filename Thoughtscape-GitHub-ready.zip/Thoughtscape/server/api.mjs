import { normalizeGeneratedGraph } from "../src/domain/generatedGraph.ts";
import { graphPrompt } from "./prompt.mjs";
import { graphSchema } from "./schema.mjs";

export class ServiceError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}
export function serviceConfig(env) {
  const enabled = env.THOUGHTSCAPE_ENABLE_AI === "true";
  const key = env.THOUGHTSCAPE_API_KEY?.trim();
  const model = env.THOUGHTSCAPE_MODEL?.trim();
  const base = env.THOUGHTSCAPE_BASE_URL?.trim() || "http://127.0.0.1:11434/v1";
  let endpoint;
  try {
    const url = new URL(base.replace(/\/$/, "") + "/chat/completions");
    if (
      url.protocol !== "https:" &&
      !(
        url.protocol === "http:" &&
        ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname)
      )
    )
      throw new Error();
    if (url.username || url.password || url.search || url.hash)
      throw new Error();
    endpoint = url.href;
  } catch {
    throw new ServiceError(503, "AI 服务地址无效，请检查本地配置。");
  }
  const tokenParam =
    env.THOUGHTSCAPE_TOKEN_PARAM ||
    (new URL(endpoint).hostname === "api.openai.com"
      ? "max_completion_tokens"
      : "max_tokens");
  if (!["max_completion_tokens", "max_tokens"].includes(tokenParam))
    throw new ServiceError(503, "AI 输出长度配置无效。");
  const local = ["localhost", "127.0.0.1", "[::1]"].includes(
    new URL(endpoint).hostname,
  );
  const paidBlocked = !local && env.THOUGHTSCAPE_ALLOW_PAID_API !== "true";
  return {
    local,
    paidBlocked,
    enabled,
    key,
    model,
    endpoint,
    tokenParam,
    structured: new URL(endpoint).hostname === "api.openai.com",
    configured: enabled && !paidBlocked && !!model && (local || !!key),
  };
}
export async function generateGraph(
  question,
  config,
  { fetchImpl = fetch, signal } = {},
) {
  if (!config.enabled)
    throw new ServiceError(403, "AI 接口默认关闭，当前仅使用预置演示地图。");
  if (config.paidBlocked)
    throw new ServiceError(
      403,
      "付费 API 调用已禁用，不会消耗你的 API token。请使用本地模型。",
    );
  if (!config.configured)
    throw new ServiceError(
      503,
      "尚未配置本地 AI 模型，请先按首页说明启动本地 DeepSeek。",
    );
  let upstream;
  try {
    upstream = await fetchImpl(config.endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${config.local ? "ollama" : config.key}`,
      },
      signal,
      body: JSON.stringify({
        model: config.model,
        messages: [
          { role: "system", content: graphPrompt },
          { role: "user", content: JSON.stringify({ question }) },
        ],
        response_format: config.structured
          ? {
              type: "json_schema",
              json_schema: {
                name: "thoughtscape_graph",
                strict: true,
                schema: graphSchema,
              },
            }
          : { type: "json_object" },
        [config.tokenParam || "max_completion_tokens"]: 8192,
      }),
    });
  } catch (error) {
    if (signal?.aborted)
      throw new ServiceError(504, "生成已取消或等待超时，可以稍后重试。");
    throw new ServiceError(502, "无法连接 AI 服务，请检查服务地址和网络。");
  }
  if (!upstream.ok) {
    // Provider messages may contain request details. Never relay them or keys.
    const message =
      upstream.status === 401 || upstream.status === 403
        ? "API Key 无效或没有所选模型的访问权限。"
        : upstream.status === 429
          ? "AI 服务余额不足或请求过于频繁，请检查账户后重试。"
          : "AI 服务未接受请求，请检查模型名称、接口兼容性或稍后重试。";
    throw new ServiceError(502, message);
  }
  try {
    const body = await upstream.json(),
      choice = body.choices?.[0];
    if (
      choice?.finish_reason !== "stop" ||
      !choice.message?.content ||
      choice.message.refusal
    )
      throw new Error("incomplete");
    return normalizeGeneratedGraph(
      JSON.parse(choice.message.content),
      question,
      config.model,
    );
  } catch {
    throw new ServiceError(
      502,
      "AI 返回的地图不完整或不符合结构要求。请重试，或换一个更明确的问题。",
    );
  }
}
function send(res, status, body) {
  if (res.destroyed || res.writableEnded) return;
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
  });
  res.end(JSON.stringify(body));
}
export function createAIMiddleware(readConfig) {
  let busy = false;
  return async (req, res) => {
    const path = req.url?.split("?")[0];
    if (
      req.headers.origin &&
      req.headers.origin !== `http://${req.headers.host}` &&
      req.headers.origin !== `https://${req.headers.host}`
    )
      return send(res, 403, { error: "仅允许从本地 Thoughtscape 页面访问。" });
    try {
      if (path === "/status" && req.method === "GET") {
        const config = readConfig();
        return send(res, 200, {
          configured: config.configured,
          enabled: config.enabled,
          model: config.configured ? config.model : null,
          provider: new URL(config.endpoint).hostname,
          local: config.local,
          paidBlocked: config.paidBlocked,
        });
      }
      if (path !== "/generate" || req.method !== "POST")
        return send(res, 404, { error: "接口不存在。" });
      if (!req.headers["content-type"]?.startsWith("application/json"))
        return send(res, 415, { error: "请求必须使用 JSON。" });
      if (busy)
        return send(res, 429, { error: "已有一个问题正在生成，请稍后再试。" });
      let bytes = 0,
        buffer = [];
      for await (const chunk of req) {
        bytes += chunk.length;
        if (bytes > 4096)
          return send(res, 413, { error: "问题过长，请控制在 300 字以内。" });
        buffer.push(chunk);
      }
      let body;
      try {
        body = JSON.parse(Buffer.concat(buffer).toString("utf8"));
      } catch {
        throw new ServiceError(400, "请求内容不是有效 JSON。");
      }
      if (
        typeof body.question !== "string" ||
        !body.question.trim() ||
        body.question.trim().length > 300
      )
        throw new ServiceError(400, "请输入 1 至 300 字的问题。");
      if (busy)
        return send(res, 429, { error: "已有一个问题正在生成，请稍后再试。" });
      const config = readConfig();
      if (!config.enabled)
        throw new ServiceError(
          403,
          "AI 接口默认关闭，当前仅使用预置演示地图。",
        );
      if (config.paidBlocked)
        throw new ServiceError(
          403,
          "付费 API 调用已禁用，不会消耗你的 API token。请使用本地模型。",
        );
      if (!config.configured)
        throw new ServiceError(
          503,
          "尚未配置本地 AI 模型，请先启动本地 DeepSeek。",
        );
      busy = true;
      const controller = new AbortController(),
        timer = setTimeout(() => controller.abort(), 110000);
      const disconnect = () => {
        if (!res.writableEnded) controller.abort();
      };
      res.on("close", disconnect);
      try {
        send(
          res,
          200,
          await generateGraph(body.question.trim(), config, {
            signal: controller.signal,
          }),
        );
      } finally {
        clearTimeout(timer);
        res.off("close", disconnect);
        busy = false;
      }
    } catch (error) {
      send(res, error instanceof ServiceError ? error.status : 500, {
        error:
          error instanceof ServiceError
            ? error.message
            : "本地 AI 服务遇到问题，请稍后重试。",
      });
    }
  };
}
