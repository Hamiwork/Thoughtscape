import { useCallback, useEffect, useRef, useState } from "react";
import type { MapPreview } from "../types/knowledge";

export function useMapPreview() {
  const [preview, setPreview] = useState<MapPreview | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const blockedUntil = useRef(0);
  const keyboardInput = useRef(false);
  const cancelTimer = useCallback(() => clearTimeout(timer.current), []);
  const clear = useCallback(() => {
    cancelTimer();
    setPreview(null);
  }, [cancelTimer]);
  // Keep the pointer-down target stable until click or drag commits the action.
  const hold = useCallback(() => {
    keyboardInput.current = false;
    blockedUntil.current = Date.now() + 280;
    cancelTimer();
  }, [cancelTimer]);
  const enter = useCallback(
    (next: MapPreview, keyboard = false) => {
      cancelTimer();
      if (keyboard) {
        if (keyboardInput.current) setPreview(next);
        return;
      }
      keyboardInput.current = false;
      if (
        !window.matchMedia("(hover: hover) and (pointer: fine)").matches ||
        Date.now() < blockedUntil.current
      )
        return;
      timer.current = setTimeout(() => setPreview(next), 110);
    },
    [cancelTimer],
  );
  const leave = useCallback(() => {
    cancelTimer();
    timer.current = setTimeout(() => setPreview(null), 90);
  }, [cancelTimer]);
  const suspend = useCallback(() => {
    hold();
    clear();
  }, [hold, clear]);
  useEffect(() => {
    const markKeyboard = () => {
      keyboardInput.current = true;
    };
    window.addEventListener("keydown", markKeyboard, true);
    return () => {
      window.removeEventListener("keydown", markKeyboard, true);
      cancelTimer();
    };
  }, [cancelTimer]);
  return { preview, enter, leave, clear, hold, suspend };
}
