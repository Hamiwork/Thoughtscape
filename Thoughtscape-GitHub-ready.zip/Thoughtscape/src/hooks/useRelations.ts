import { useMemo, useReducer } from "react";
import { knowledgeReducer } from "../domain/relations";
import { useKnowledge } from "../context/KnowledgeContext";
import type { KnowledgeState, KnowledgeAction } from "../domain/relations";
export function useRelations() {
  const data = useKnowledge();
  const initialState = useMemo<KnowledgeState>(
    () => ({
      concepts: data.concepts,
      relations: data.relations,
      history: [],
      notice: "",
    }),
    [data],
  );
  const [state, dispatch] = useReducer(
    (state: KnowledgeState, action: KnowledgeAction) =>
      knowledgeReducer(state, action, initialState),
    initialState,
  );
  return {
    ...state,
    dispatch,
    canUndo: state.history.length > 0,
    modifiedCount:
      state.relations.filter((r) => r.assessment.origin === "user").length +
      state.concepts.filter(
        (c, i) =>
          JSON.stringify(c.stanceIds) !==
          JSON.stringify(initialState.concepts[i].stanceIds),
      ).length,
  };
}
