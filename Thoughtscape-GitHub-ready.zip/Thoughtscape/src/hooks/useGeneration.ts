import { useEffect, useRef, useState } from "react";
import type { KnowledgeDataset } from "../types/knowledge";
export interface AIStatus {
  configured: boolean;
  enabled: boolean;
  model: string | null;
  provider: string;
  local: boolean;
  paidBlocked: boolean;
}
export function useGeneration() {
  const [status, setStatus] = useState<AIStatus | null>(null);
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const request = useRef<AbortController | null>(null);
  const staticDemo = import.meta.env.VITE_STATIC_DEMO === "true";
  const refresh = async () => {
    if (staticDemo) {
      setStatus(null);
      return;
    }
    try {
      const response = await fetch("/api/status");
      if (!response.ok) throw new Error();
      setStatus(await response.json());
    } catch {
      setStatus(null);
    }
  };
  useEffect(() => {
    void refresh();
    return () => request.current?.abort();
  }, []);
  const cancel = () => {
    request.current?.abort();
    request.current = null;
    setBusy(false);
    setError("已取消生成，问题已保留。");
  };
  const generate = async (
    question: string,
  ): Promise<KnowledgeDataset | null> => {
    if (staticDemo) {
      setError(
        "在线演示仅使用预置地图。接入自己的 AI 请下载源码后在本地运行。",
      );
      return null;
    }
    request.current?.abort();
    const controller = new AbortController();
    request.current = controller;
    setBusy(true);
    setError("");
    const timer = setTimeout(() => controller.abort(), 120000);
    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question }),
        signal: controller.signal,
      });
      const body = await response.json();
      if (!response.ok) throw new Error(body.error || "生成未完成，请重试。");
      if (
        body.mode !== "ai" ||
        !Array.isArray(body.concepts) ||
        !Array.isArray(body.relations)
      )
        throw new Error("服务返回的地图格式无效。");
      return request.current === controller ? (body as KnowledgeDataset) : null;
    } catch (cause) {
      if (request.current === controller)
        setError(
          controller.signal.aborted
            ? "等待超时或已取消，问题已保留，可以重试。"
            : cause instanceof Error
              ? cause.message
              : "无法连接本地 AI 服务。",
        );
      return null;
    } finally {
      clearTimeout(timer);
      if (request.current === controller) {
        request.current = null;
        setBusy(false);
      }
    }
  };
  return {
    status,
    busy,
    error,
    generate,
    cancel,
    refresh,
    clearError: () => setError(""),
  };
}
