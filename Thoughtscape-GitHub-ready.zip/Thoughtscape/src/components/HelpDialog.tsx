import { useEffect, useRef } from "react";
import { useKnowledge } from "../context/KnowledgeContext";
import { X } from "lucide-react";
export function HelpDialog({ onClose }: { onClose: () => void }) {
  const { dataNotice, mode } = useKnowledge();
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    ref.current?.showModal();
  }, []);
  return (
    <dialog
      ref={ref}
      className="help-dialog"
      onCancel={onClose}
      onClick={(e) => {
        if (e.target === ref.current) onClose();
      }}
    >
      <button
        className="dialog-close"
        onClick={onClose}
        aria-label="关闭探索指南"
      >
        <X size={18} />
      </button>
      <span className="eyebrow">一张地图，不是一个标准答案</span>
      <h2>从一个词，走向更多理解。</h2>
      <ol>
        <li>
          <strong>先看结构</strong>
          <p>
            鼠标悬停放大关键词并预览关联，移开恢复；单击固定探索。拖动空白处平移，滚轮缩放，关键词可以拖动。点击任意词，高亮一步关联；展开二步、三步关联只改变强调，不创建重复节点。
          </p>
        </li>
        <li>
          <strong>换一个论证视角</strong>
          <p>
            支持、质疑与条件不是情绪。切换视角保留空间结构，淡化的词和跨立场关系仍可点击。
          </p>
        </li>
        <li>
          <strong>沿关系追问</strong>
          <p>
            点击线或关系标签，检查具体语义、相关观点、适用条件与材料。历史箭头返回原位置，关键词足迹可以再次打开。
          </p>
        </li>
        <li>
          <strong>放进自己的理解</strong>
          <p>
            修改关系类型、短标签和备注，或改为待判断。关键词可关联多个立场，可修改标注。支持撤销；关键词查找中可恢复初始数据。
          </p>
        </li>
      </ol>
      <p className="help-footnote">
        {dataNotice}。
        {mode === "ai"
          ? "本图未检索外部资料，不提供已验证的原文证据。"
          : "全部材料为自行构造情景，非真实引文。"}
        修改只在当前会话内保存，刷新后清除。重置视图只恢复布局。
      </p>
      <button className="primary-button" onClick={onClose}>
        开始探索 →
      </button>
    </dialog>
  );
}
