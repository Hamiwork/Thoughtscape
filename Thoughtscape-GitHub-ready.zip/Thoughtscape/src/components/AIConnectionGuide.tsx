import { ChevronDown, Plug } from "lucide-react";
import type { RefObject } from "react";

const cloudConfig = `THOUGHTSCAPE_ENABLE_AI=true
THOUGHTSCAPE_BASE_URL=https://api.openai.com/v1
THOUGHTSCAPE_MODEL=替换为你的模型ID
THOUGHTSCAPE_API_KEY=替换为你的API_Key
THOUGHTSCAPE_ALLOW_PAID_API=true`;

export function AIConnectionGuide({
  enabled,
  detailsRef,
}: {
  enabled: boolean;
  detailsRef: RefObject<HTMLDetailsElement | null>;
}) {
  return (
    <details
      id="ai-connection-guide"
      className="connection-guide"
      ref={detailsRef}
    >
      <summary>
        <Plug size={14} />
        <span>接入自己的 AI</span>
        <small>{enabled ? "已由使用者开启" : "可选 · 默认关闭"}</small>
        <ChevronDown className="connection-chevron" size={14} />
      </summary>
      <div className="connection-guide-body">
        {import.meta.env.VITE_STATIC_DEMO === "true" && (
          <p className="connection-boundary">
            这是 GitHub Pages 在线演示，仅提供预置地图。接入自己的 AI
            需要下载项目源码，在本机或支持后端服务的环境中运行；不能直接在此网页填写
            Key。
          </p>
        )}
        <p className="connection-intro">
          想探索演示列表之外的问题？可以连接自己的模型服务。当前支持 OpenAI
          兼容的 Chat Completions 接口，模型需支持 JSON 输出。
        </p>
        <ol>
          <li>
            <strong>准备自己的服务与凭证</strong>
            <p>
              从服务商获取 API 基础地址、模型 ID 和 API Key。 地址不要包含末尾的{" "}
              <code>/chat/completions</code>。
            </p>
          </li>
          <li>
            <strong>填写项目内的本地配置</strong>
            <p>
              将项目文件夹中的 <code>.env.example</code> 复制为
              <code> .env.local</code>；如果已经存在，编辑原文件即可。
              以下是云端接口示例，请替换地址、模型和 Key：
            </p>
            <pre aria-label="云端 AI 配置示例">
              <code>{cloudConfig}</code>
            </pre>
            <p>
              使用已运行的本地模型时，可将地址改为
              <code> http://127.0.0.1:11434/v1</code>，填写已安装的模型名称，
              API Key 留空，并保持
              <code> THOUGHTSCAPE_ALLOW_PAID_API=false</code>。
              本项目不会自动安装或下载模型。
            </p>
          </li>
          <li>
            <strong>重启项目，再输入新问题</strong>
            <p>
              先在运行服务的终端按 <code>Ctrl+C</code> 停止服务，再运行
              <code> pnpm dev</code>
              ，或双击桌面的启动脚本。随后刷新页面。首页显示已配置的模型后，提交未收录的新问题即可生成地图。
            </p>
          </li>
        </ol>
        <div className="connection-boundary">
          <p>
            <strong>费用由你控制。</strong>预置地图不调用 AI。
            只有主动开启接入并提交未收录的问题，才会调用配置的服务；云端费用按服务商规则计入你自己的账户。
          </p>
          <p>
            Key 仅放在本地配置中，不要加 <code>VITE_</code>{" "}
            前缀，也不要提交到代码仓库或发给他人。 关闭时将{" "}
            <code>THOUGHTSCAPE_ENABLE_AI</code> 改回 <code>false</code> 并重启。
            AI 生成内容仍需核实，不会自动成为已验证的证据。
          </p>
        </div>
      </div>
    </details>
  );
}
