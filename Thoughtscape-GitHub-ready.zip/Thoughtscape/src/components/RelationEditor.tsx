import { useEffect, useState } from "react";
import { relationMeta } from "../data/relations";
import { validateAssessment } from "../domain/relations";
import type { Relation, RelationKind } from "../types/knowledge";
import type { KnowledgeAction } from "../domain/relations";
export function RelationEditor({
  relation,
  dispatch,
}: {
  relation: Relation;
  dispatch: (a: KnowledgeAction) => void;
}) {
  const [kind, setKind] = useState(relation.assessment.kind),
    [label, setLabel] = useState(relation.assessment.label),
    [reason, setReason] = useState(relation.assessment.reason),
    [confirmed, setConfirmed] = useState(false),
    [error, setError] = useState("");
  useEffect(() => {
    setKind(relation.assessment.kind);
    setLabel(relation.assessment.label);
    setReason(relation.assessment.reason);
    setConfirmed(false);
    setError("");
  }, [relation]);
  const dirty =
    kind !== relation.assessment.kind ||
    label !== relation.assessment.label ||
    reason !== relation.assessment.reason;
  return (
    <form
      className="relationship-editor"
      onSubmit={(e) => {
        e.preventDefault();
        const error = validateAssessment(kind, label, reason, confirmed);
        if (error) {
          setError(error);
          return;
        }
        dispatch({
          type: "relation",
          id: relation.id,
          kind,
          label,
          reason,
          confirmed,
        });
      }}
    >
      <label htmlFor="relationship-kind">关系类型</label>
      <select
        id="relationship-kind"
        value={kind}
        onChange={(e) => {
          const next = e.target.value as RelationKind;
          setKind(next);
          setLabel(relationMeta[next].label);
          setReason("");
          setError("");
          setConfirmed(false);
        }}
      >
        {Object.entries(relationMeta).map(([id, m]) => (
          <option key={id} value={id}>
            {m.label} · {m.description}
          </option>
        ))}
      </select>
      <label htmlFor="relationship-label">地图上的短标签</label>
      <input
        id="relationship-label"
        value={label}
        maxLength={12}
        onChange={(e) => setLabel(e.target.value)}
      />
      <label htmlFor="relationship-reason">判断备注</label>
      <textarea
        id="relationship-reason"
        rows={3}
        value={reason}
        placeholder="为什么这样理解？哪些条件影响判断？"
        onChange={(e) => setReason(e.target.value)}
      />
      {kind === "conflict" && (
        <label className="scope-confirm">
          <input
            type="checkbox"
            checked={confirmed}
            onChange={(e) => setConfirmed(e.target.checked)}
          />
          我在相同场景与评价标准下比较，仍判断两者难以同时成立。
        </label>
      )}
      {error && (
        <p className="editor-error" role="alert">
          {error}
        </p>
      )}
      <button type="submit" className="primary-button" disabled={!dirty}>
        应用关系修改
      </button>
      <small>仅更新你的解释，不改写原文或提高验证状态。</small>
    </form>
  );
}
