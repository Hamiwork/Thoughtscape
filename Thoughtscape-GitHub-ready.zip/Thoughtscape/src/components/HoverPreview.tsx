import { relationMeta } from "../data/demo";
import { useKnowledge } from "../context/KnowledgeContext";
import { incidentRelations } from "../domain/exploration";
import type { MapPreview, Relation } from "../types/knowledge";
export function HoverPreview({
  preview,
  relations,
}: {
  preview: MapPreview | null;
  relations: Relation[];
}) {
  const { conceptById, issue } = useKnowledge();
  if (!preview) return null;
  const relation =
    preview.type === "relation"
      ? relations.find((r) => r.id === preview.id)
      : null;
  const concept = preview.type === "concept" ? conceptById[preview.id] : null;
  return (
    <div className="hover-preview" data-testid="hover-preview" role="status">
      <span>
        {relation ? "关系预览" : concept ? "关键词预览" : "议题起点"}
        <small>单击固定探索</small>
      </span>
      <strong>
        {relation
          ? `${conceptById[relation.sourceId].name} → ${conceptById[relation.targetId].name}`
          : (concept?.name ?? issue.name)}
      </strong>
      <p>
        {relation
          ? relation.assessment.label ===
            relationMeta[relation.assessment.kind].label
            ? relation.assessment.label
            : `${relationMeta[relation.assessment.kind].label} · ${relation.assessment.label}`
          : (concept?.explanation ?? issue.explanation)}
      </p>
      <small>
        {concept
          ? `${incidentRelations(concept.id, relations).length} 条直接关系 · 移开恢复当前视图`
          : relation
            ? "查看成立条件、不同立场与相关依据"
            : "从任意关键词出发"}
      </small>
    </div>
  );
}
