import { X, ArrowUpRight } from "lucide-react";
import { useKnowledge } from "../context/KnowledgeContext";
import type { Selection } from "../types/knowledge";
export function SourceLibrary({
  onSelect,
  onClose,
}: {
  onSelect: (s: Selection) => void;
  onClose: () => void;
}) {
  const { sources, dataNotice, mode } = useKnowledge();
  return (
    <section className="source-library" aria-label="来源材料">
      <header>
        <span>资料档案 / {sources.length} 份材料</span>
        <button onClick={onClose} aria-label="关闭来源材料">
          <X size={17} />
        </button>
      </header>
      <h2>检查依据，也检查边界。</h2>
      <p>
        {dataNotice}。
        {mode === "ai"
          ? "本次生成没有检索外部资料，因此没有可展示的原文证据。AI 推断不等同于已验证结论。"
          : "演示中的材料如有展示，均为产品设计情景；没有核实的真实文章、作者或研究。"}
      </p>
      <div className="archive-list">
        {sources.map((s) => (
          <button
            className="library-entry"
            key={s.id}
            onClick={() => onSelect({ type: "source", id: s.id })}
          >
            <span>{s.code}</span>
            <div>
              <h3>{s.title}</h3>
              <p>{s.description}</p>
              <small>构造材料 · 非真实引文</small>
            </div>
            <ArrowUpRight size={17} />
          </button>
        ))}
      </div>
    </section>
  );
}
