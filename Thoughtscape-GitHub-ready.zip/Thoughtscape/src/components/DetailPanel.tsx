import { useRef } from "react";
import { ArrowLeft, ArrowRight, Focus, X, Undo2 } from "lucide-react";
import { useKnowledge } from "../context/KnowledgeContext";
import { relationMeta } from "../data/demo";
import {
  incidentRelations,
  isCrossStance,
  relationStances,
} from "../domain/exploration";
import type { KnowledgeAction } from "../domain/relations";
import type { Concept, Relation, Selection } from "../types/knowledge";
import { StanceBadges, StanceEditor } from "./StanceControls";
import {
  EvidenceButton,
  EvidenceDetails,
  SourceDetails,
} from "./EvidenceDetails";
import { RelationEditor } from "./RelationEditor";
interface Props {
  selection: Selection;
  concepts: Concept[];
  relations: Relation[];
  onSelect: (s: Selection) => void;
  onBack: () => void;
  canBack: boolean;
  onFocus: (ids: string[]) => void;
  depth: number;
  onDepth: (d: number) => void;
  dispatch: (a: KnowledgeAction) => void;
  canUndo: boolean;
}
export function DetailPanel({
  selection,
  concepts,
  relations,
  onSelect,
  onBack,
  canBack,
  onFocus,
  depth,
  onDepth,
  dispatch,
  canUndo,
}: Props) {
  const {
    concepts: initialConcepts,
    claims,
    claimById,
    conceptById,
    evidenceById,
    evidence,
    issue,
    dataNotice,
    mode,
  } = useKnowledge();
  const editor = useRef<HTMLDetailsElement>(null);
  if (!selection) return null;
  const concept =
    selection.type === "concept"
      ? concepts.find((c) => c.id === selection.id)
      : undefined;
  const relation =
    selection.type === "relation"
      ? relations.find((r) => r.id === selection.id)
      : undefined;
  const claim =
    selection.type === "claim" ? claimById[selection.id] : undefined;
  const cross = relation && isCrossStance(relation, claimById);
  return (
    <aside className="detail-panel" aria-label="探索详情">
      <header className="detail-top">
        <button
          onClick={onBack}
          disabled={!canBack}
          aria-label="返回上一个探索位置"
        >
          <ArrowLeft size={16} />
        </button>
        <span>
          {relation
            ? cross
              ? "分歧探索"
              : "关系探索"
            : concept
              ? "关键词探索"
              : selection.type === "evidence"
                ? "证据检查"
                : selection.type === "source"
                  ? "来源检查"
                  : claim
                    ? "观点检查"
                    : "探索议题"}{" "}
          / {relation?.id.toUpperCase() ?? ""}
        </span>
        <button onClick={() => onSelect(null)} aria-label="关闭详情，返回全局">
          <X size={16} />
        </button>
      </header>
      <div className="detail-scroll" key={selection.type + selection.id}>
        {concept && (
          <>
            <span className="panel-kicker">
              {concept.type === "condition" ? "◇ 条件关键词" : "概念关键词"} ·{" "}
              {String(concepts.indexOf(concept) + 1).padStart(2, "0")}
            </span>
            <h2>{concept.name}</h2>
            <p className="concept-explanation">{concept.explanation}</p>
            <section>
              <h3>从不同立场理解</h3>
              <StanceBadges ids={concept.stanceIds} />
              <small className="explain-note">
                标注的是论证关联，不是情绪或概念的固定阵营。
              </small>
              {JSON.stringify(concept.stanceIds) !==
                JSON.stringify(
                  initialConcepts.find((c) => c.id === concept.id)!.stanceIds,
                ) && <small className="user-tag">你的立场标注</small>}
            </section>
            <section>
              <h3>
                沿关系继续探索{" "}
                <small>
                  {incidentRelations(concept.id, relations).length} 个方向
                </small>
              </h3>
              <div className="explore-directions">
                {incidentRelations(concept.id, relations).map((r) => {
                  const next =
                    r.sourceId === concept.id ? r.targetId : r.sourceId;
                  return (
                    <div key={r.id}>
                      <button
                        onClick={() => onSelect({ type: "relation", id: r.id })}
                      >
                        <small>
                          {r.sourceId === concept.id ? "→" : "←"}{" "}
                          {r.assessment.label}
                        </small>
                        <b>理解这条关系</b>
                      </button>
                      <button
                        onClick={() => onSelect({ type: "concept", id: next })}
                      >
                        {conceptById[next].name}
                        <ArrowRight size={13} />
                      </button>
                    </div>
                  );
                })}
              </div>
              <div className="expand-actions">
                <button
                  onClick={() => onDepth(Math.min(depth + 1, 3))}
                  disabled={depth >= 3}
                >
                  展开{depth + 1}步关联
                </button>
                {depth > 1 && (
                  <button onClick={() => onDepth(1)}>收起展开</button>
                )}
                <small>沿现有概念扩展强调，不创建重复节点。</small>
              </div>
            </section>
            <details className="supporting-claims">
              <summary>相关观点与证据</summary>
              {claims
                .filter((p) => p.conceptIds.includes(concept.id))
                .map((p) => (
                  <button
                    key={p.id}
                    className="claim-button"
                    onClick={() => onSelect({ type: "claim", id: p.id })}
                  >
                    <StanceBadges ids={[p.stanceId]} />
                    <span>{p.text}</span>
                    <small>检查依据 ↗</small>
                  </button>
                ))}
            </details>
            <StanceEditor
              concept={concept}
              onSave={(ids) =>
                dispatch({ type: "stance", id: concept.id, stanceIds: ids })
              }
            />
          </>
        )}
        {relation && (
          <>
            <span className="panel-kicker">
              {cross ? "不同立场，共同讨论一个问题" : "概念之间的具体语义"} ·{" "}
              {dataNotice}
            </span>
            <div className="relation-endpoints">
              <button
                onClick={() =>
                  onSelect({ type: "concept", id: relation.sourceId })
                }
              >
                {conceptById[relation.sourceId].name}
              </button>
              <span>→</span>
              <button
                onClick={() =>
                  onSelect({ type: "concept", id: relation.targetId })
                }
              >
                {conceptById[relation.targetId].name}
              </button>
            </div>
            <h2 className="relation-verb" data-testid="detail-relation-label">
              {relation.assessment.label}
            </h2>
            <span className="relation-type">
              {relationMeta[relation.assessment.kind].symbol}{" "}
              {relationMeta[relation.assessment.kind].label} ·{" "}
              {relation.assessment.origin === "user"
                ? "你的判断"
                : mode === "ai"
                  ? "AI 推断，待核实"
                  : "演示初判"}
            </span>
            <p className="relation-explanation" data-testid="relation-reason">
              {relation.assessment.reason}
            </p>
            <StanceBadges ids={relationStances(relation, claimById)} />
            <section>
              <h3>成立条件</h3>
              <ul>
                {relation.conditions.map((c) => (
                  <li key={c}>{c}</li>
                ))}
              </ul>
            </section>
            <section>
              <h3>
                相关依据{" "}
                <small>{mode === "ai" ? "未检索外部来源" : "未核实情景"}</small>
              </h3>
              {!relation.evidenceIds.length && (
                <p className="uncertainty">
                  {mode === "ai"
                    ? "这是 AI 根据问题提出的推断"
                    : "这是用于产品演示的候选判断"}
                  ，暂无已核实证据；请先核对条件再作判断。
                </p>
              )}
              <div className="proof-links">
                {relation.evidenceIds.map((id) => (
                  <EvidenceButton key={id} id={id} onSelect={onSelect} />
                ))}
              </div>
            </section>
            <section>
              <h3>仍不确定什么</h3>
              <p className="uncertainty">{relation.uncertainty}</p>
            </section>
            <details className="relationship-arguments">
              <summary>
                {cross ? "比较不同立场的观点与条件" : "展开相关观点与条件"} ·{" "}
                {relation.claimIds.length} 个主张
              </summary>
              {relation.claimIds.map((id) => {
                const p = claimById[id];
                return (
                  <details key={id} className="argument">
                    <summary>
                      <StanceBadges ids={[p.stanceId]} />
                      <span>{p.text}</span>
                    </summary>
                    <ul>
                      {p.conditions.map((c) => (
                        <li key={c}>{c}</li>
                      ))}
                    </ul>
                    <div className="proof-links">
                      {p.evidenceIds.map((id) => (
                        <EvidenceButton key={id} id={id} onSelect={onSelect} />
                      ))}
                    </div>
                  </details>
                );
              })}
              {cross && (
                <small className="explain-note">
                  不同立场不等于同条件冲突；先对照任务、风险与评价标准。
                </small>
              )}
            </details>
            <details className="edit-relation" ref={editor}>
              <summary>修改这条关系</summary>
              <RelationEditor relation={relation} dispatch={dispatch} />
            </details>
            {canUndo && (
              <button
                className="text-action"
                onClick={() => dispatch({ type: "undo" })}
              >
                <Undo2 size={13} /> 撤销最近一次修改
              </button>
            )}
            <section>
              <h3>从端点继续</h3>
              <div className="keyword-links">
                {[relation.sourceId, relation.targetId].map((id) => (
                  <button
                    key={id}
                    onClick={() => onSelect({ type: "concept", id })}
                  >
                    {conceptById[id].name} →
                  </button>
                ))}
              </div>
            </section>
          </>
        )}
        {selection.type === "evidence" && (
          <EvidenceDetails id={selection.id} onSelect={onSelect} />
        )}
        {selection.type === "source" && (
          <SourceDetails id={selection.id} onSelect={onSelect} />
        )}
        {claim && (
          <>
            <span className="panel-kicker">观点 / 非实证结论</span>
            <StanceBadges ids={[claim.stanceId]} />
            <h2 className="claim-statement">{claim.text}</h2>
            <section>
              <h3>成立条件</h3>
              <ul>
                {claim.conditions.map((c) => (
                  <li key={c}>{c}</li>
                ))}
              </ul>
            </section>
            <section>
              <h3>依据与局限</h3>
              {!claim.evidenceIds.length && (
                <p className="uncertainty">
                  {mode === "ai" ? "AI 生成的候选观点" : "演示用候选观点"}
                  ，暂无已核实来源或原文引文。
                </p>
              )}
              {claim.evidenceIds.map((id) => (
                <EvidenceButton key={id} id={id} onSelect={onSelect} />
              ))}
            </section>
            <section>
              <h3>相关关键词</h3>
              <div className="keyword-links">
                {claim.conceptIds.map((id) => (
                  <button
                    key={id}
                    onClick={() => onSelect({ type: "concept", id })}
                  >
                    {conceptById[id].name} ↗
                  </button>
                ))}
              </div>
            </section>
          </>
        )}
        {selection.type === "issue" && (
          <>
            <span className="panel-kicker">议题 001 / 开放探索</span>
            <h2>{issue.question}</h2>
            <p>{issue.explanation}</p>
            <section>
              <h3>任选一个入口</h3>
              <div className="keyword-links">
                {initialConcepts
                  .filter((c) => c.level === "primary")
                  .slice(0, 4)
                  .map((c) => c.id)
                  .map((id) => (
                    <button
                      key={id}
                      onClick={() => onSelect({ type: "concept", id })}
                    >
                      {conceptById[id].name} →
                    </button>
                  ))}
              </div>
            </section>
            <p className="uncertainty">{dataNotice}；地图没有预设正确答案。</p>
          </>
        )}
      </div>
      <footer className="detail-footer">
        {relation ? (
          <button
            onClick={() => {
              if (editor.current) {
                editor.current.open = true;
                editor.current.scrollIntoView({
                  behavior: "smooth",
                  block: "start",
                });
              }
            }}
          >
            重新判断关系 <ArrowRight size={13} />
          </button>
        ) : (
          <button
            onClick={() => {
              const ids = concept
                ? [concept.id]
                : selection.type === "evidence"
                  ? evidenceById[selection.id].conceptIds
                  : selection.type === "source"
                    ? evidence
                        .filter((e) => e.sourceId === selection.id)
                        .flatMap((e) => e.conceptIds)
                    : claim
                      ? claim.conceptIds
                      : ["issue"];
              onFocus(ids);
            }}
          >
            <Focus size={13} /> 在地图中聚焦
          </button>
        )}
        <small>{dataNotice}</small>
      </footer>
    </aside>
  );
}
