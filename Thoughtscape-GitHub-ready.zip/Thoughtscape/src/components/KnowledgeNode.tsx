import { memo, type CSSProperties } from "react";
import { Handle, Position, type NodeProps } from "@xyflow/react";
import { useKnowledge } from "../context/KnowledgeContext";
import type { MapNode } from "../types/knowledge";
export const KnowledgeNode = memo(function KnowledgeNode({
  data,
}: NodeProps<MapNode>) {
  const { stances } = useKnowledge();
  return (
    <article
      data-testid={`concept-${data.objectType === "issue" ? "issue" : data.name}`}
      data-object-type={data.objectType}
      data-stances={data.stanceIds.join(",")}
      className={`keyword-node ${data.level} type-${data.objectType} ${data.selected ? "chosen" : ""} ${data.related ? "related" : ""} ${data.muted ? "muted" : ""} ${data.previewed ? "is-previewed" : ""} ${data.bridge ? "is-bridge" : ""} ${data.overview ? "is-overview" : ""}`}
      data-previewed={!!data.previewed}
      style={{ "--keyword-scale": data.previewScale ?? 1 } as CSSProperties}
    >
      {(
        [
          ["left", Position.Left],
          ["right", Position.Right],
          ["top", Position.Top],
          ["bottom", Position.Bottom],
        ] as const
      ).map(([id, position]) => (
        <Handle
          key={id}
          id={id}
          type="source"
          position={position}
          isConnectable={false}
        />
      ))}
      <div className="keyword-content">
        {data.objectType === "issue" ? (
          <>
            <small>议题 / {data.number}</small>
            <h2>{data.name}</h2>
          </>
        ) : (
          <>
            <small>
              {data.number}
              {data.objectType === "condition" && <span>◇ 条件</span>}
            </small>
            <h3>{data.name}</h3>
            <div
              className="node-perspectives"
              aria-label={
                data.stanceIds.length
                  ? data.stanceIds.map((id) => stances[id].label).join("、")
                  : "立场未标注"
              }
            >
              {data.stanceIds.map((id) => (
                <span
                  key={id}
                  title={stances[id].label}
                  style={{ color: stances[id].color }}
                >
                  {stances[id].symbol}
                </span>
              ))}
            </div>
          </>
        )}
      </div>
    </article>
  );
});
