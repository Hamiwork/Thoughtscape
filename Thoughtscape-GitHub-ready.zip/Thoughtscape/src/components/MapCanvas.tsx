import { useCallback, useEffect, useMemo, useRef } from "react";
import {
  ReactFlow,
  ConnectionMode,
  Panel,
  useNodesState,
  useReactFlow,
  useViewport,
  MarkerType,
  type Viewport,
} from "@xyflow/react";
import { Focus, Plus, Minus } from "lucide-react";
import { mapNodes } from "../data/map";
import { relationMeta } from "../data/relations";
import { isCrossStance } from "../domain/exploration";
import type {
  CameraRequest,
  Concept,
  MapNode,
  MapEdge,
  Relation,
  Selection,
  StanceFilter,
} from "../types/knowledge";
import { KnowledgeNode } from "./KnowledgeNode";
import { RelationEdge } from "./RelationEdge";
import { SelectionContext } from "./SelectionContext";
import { PreviewContext } from "./PreviewContext";
import { HoverPreview } from "./HoverPreview";
import { useMapPreview } from "../hooks/useMapPreview";
import { useKnowledge } from "../context/KnowledgeContext";
import { mapEmphasis } from "../domain/emphasis";
const nodeTypes = { knowledge: KnowledgeNode },
  edgeTypes = { relation: RelationEdge };
interface Props {
  concepts: Concept[];
  relations: Relation[];
  selection: Selection;
  onSelect: (s: Selection) => void;
  stance: StanceFilter;
  spotlight: Set<string> | null;
  activeIds: Set<string>;
  camera: CameraRequest | null;
  onViewport: (v: Viewport) => void;
  resetKey: number;
}
export function MapCanvas({
  concepts,
  relations,
  selection,
  onSelect,
  stance,
  spotlight,
  activeIds,
  camera,
  onViewport,
  resetKey,
}: Props) {
  const { issue, issuePosition, claimById } = useKnowledge();
  const [nodes, setNodes, onNodesChange] = useNodesState<MapNode>(
    mapNodes(concepts, issue, issuePosition),
  );
  const { fitView, setViewport, zoomIn, zoomOut } = useReactFlow<
    MapNode,
    MapEdge
  >();
  const { zoom } = useViewport();
  const preview = useMapPreview();
  const choose = useCallback(
    (next: Selection) => {
      preview.suspend();
      onSelect(next);
    },
    [preview.suspend, onSelect],
  );
  useEffect(() => {
    preview.suspend();
  }, [selection, stance, resetKey, preview.suspend]);
  const emphasis = useMemo(
    () =>
      mapEmphasis(
        concepts,
        relations,
        stance,
        spotlight,
        activeIds,
        preview.preview,
        claimById,
      ),
    [concepts, relations, stance, spotlight, activeIds, preview.preview],
  );
  const overviewLabelIds = useMemo(
    () =>
      new Set(
        relations
          .filter((r) => r.featured && emphasis.matchingEdges.has(r.id))
          .sort((a, b) => {
            const score = (r: Relation) =>
              Number(isCrossStance(r, claimById)) * 2 +
              Number(r.assessment.kind === "risk") +
              Number(
                concepts.find((c) => c.id === r.sourceId)?.level ===
                  "primary" &&
                  concepts.find((c) => c.id === r.targetId)?.level ===
                    "primary",
              );
            return score(b) - score(a);
          })
          .slice(0, zoom < 0.7 ? 5 : 8)
          .map((r) => r.id),
      ),
    [relations, concepts, emphasis.matchingEdges, zoom],
  );
  const frame = useRef<HTMLDivElement>(null);
  const latest = useRef({ camera, selection });
  latest.current = { camera, selection };
  const applyCamera = useCallback(() => {
    const c = latest.current.camera;
    if (c?.viewport) {
      void setViewport(c.viewport);
      return;
    }
    const mobile =
      window.matchMedia("(max-width:680px)").matches &&
      !!latest.current.selection;
    void fitView({
      nodes: c?.ids?.length ? c.ids.map((id) => ({ id })) : undefined,
      padding: {
        top: "150px",
        bottom: mobile ? "60%" : "80px",
        left: "40px",
        right: "40px",
      },
      maxZoom: c?.ids?.length ? 1.15 : 1.02,
      minZoom: 0.12,
    });
  }, [fitView, setViewport]);
  useEffect(() => {
    const handle = requestAnimationFrame(applyCamera);
    return () => cancelAnimationFrame(handle);
  }, [camera, applyCamera]);
  useEffect(() => {
    const ob = new ResizeObserver(() => requestAnimationFrame(applyCamera));
    if (frame.current) ob.observe(frame.current);
    return () => ob.disconnect();
  }, [applyCamera]);
  useEffect(() => {
    if (resetKey) {
      setNodes(mapNodes(concepts, issue, issuePosition));
      requestAnimationFrame(applyCamera);
    }
  }, [resetKey]);
  const visible = useMemo(
    () =>
      nodes.map((node) => {
        const c = concepts.find((x) => x.id === node.id),
          state = emphasis.nodes.get(node.id)!;
        return {
          ...node,
          zIndex: state.previewed
            ? 20
            : activeIds.has(node.id)
              ? 4
              : state.related
                ? 2
                : 0,
          selected: selection?.type === "concept" && selection.id === node.id,
          data: {
            ...node.data,
            stanceIds: c?.stanceIds ?? [],
            ...state,
            selected: activeIds.has(node.id),
            previewScale: state.previewed
              ? Math.max(1.1, Math.min(1.6, 0.95 / zoom))
              : 1,
          },
        };
      }),
    [nodes, concepts, emphasis, activeIds, selection, zoom],
  );
  const edges = useMemo<MapEdge[]>(
    () =>
      relations.map((r) => {
        const a = nodes.find((n) => n.id === r.sourceId)!,
          b = nodes.find((n) => n.id === r.targetId)!;
        const ax = a.position.x + 75,
          ay = a.position.y + 30,
          bx = b.position.x + 75,
          by = b.position.y + 30,
          dx = bx - ax,
          dy = by - ay;
        const horizontal = Math.abs(dx) > Math.abs(dy) * 1.15;
        const handles = horizontal
          ? dx > 0
            ? ["right", "left"]
            : ["left", "right"]
          : dy > 0
            ? ["bottom", "top"]
            : ["top", "bottom"];
        const chosen = selection?.type === "relation" && selection.id === r.id;
        const state = emphasis.edges.get(r.id)!;
        const previewLabel =
          state.previewed &&
          (preview.preview?.type !== "concept" || Math.hypot(dx, dy) > 340);
        const incident =
          !preview.preview &&
          selection?.type === "concept" &&
          (r.sourceId === selection.id || r.targetId === selection.id);
        return {
          id: r.id,
          type: "relation",
          source: r.sourceId,
          target: r.targetId,
          sourceHandle: handles[0],
          targetHandle: handles[1],
          selected: chosen,
          zIndex: chosen ? 3 : state.previewed ? 1 : 0,
          markerEnd: [
            "tradeoff",
            "complement",
            "uncertain",
            "conflict",
          ].includes(r.assessment.kind)
            ? undefined
            : {
                type: MarkerType.ArrowClosed,
                width: 12,
                height: 12,
                color: relationMeta[r.assessment.kind].color,
              },
          data: {
            relation: r,
            ...state,
            showLabel:
              chosen ||
              previewLabel ||
              incident ||
              (!preview.preview && !spotlight && overviewLabelIds.has(r.id)),
            crossStance: isCrossStance(r, claimById),
          },
          ariaLabel: `${r.assessment.label}，点击探索关系`,
        };
      }),
    [
      nodes,
      relations,
      selection,
      spotlight,
      emphasis,
      preview.preview,
      overviewLabelIds,
    ],
  );
  return (
    <SelectionContext.Provider value={choose}>
      <PreviewContext.Provider
        value={{ enter: preview.enter, leave: preview.leave }}
      >
        <div
          ref={frame}
          className="map-canvas"
          aria-label="关键词知识网络"
          onMouseLeave={preview.clear}
          onPointerDownCapture={preview.hold}
          onFocusCapture={(event) => {
            const id = (event.target as HTMLElement)
              .closest(".react-flow__node")
              ?.getAttribute("data-id");
            if (id)
              preview.enter(
                { type: id === "issue" ? "issue" : "concept", id },
                true,
              );
            else if (!(event.target as HTMLElement).closest(".edge-label"))
              preview.clear();
          }}
          onBlurCapture={(event) => {
            if (!event.currentTarget.contains(event.relatedTarget as Node))
              preview.clear();
          }}
          onKeyDownCapture={(e) => {
            if (e.key !== "Enter" && e.key !== " ") return;
            const id = (e.target as HTMLElement)
              .closest(".react-flow__node")
              ?.getAttribute("data-id");
            if (id) {
              e.preventDefault();
              choose({ type: id === "issue" ? "issue" : "concept", id });
            }
          }}
        >
          <ReactFlow<MapNode, MapEdge>
            nodes={visible}
            edges={edges}
            nodeTypes={nodeTypes}
            edgeTypes={edgeTypes}
            connectionMode={ConnectionMode.Loose}
            onNodesChange={(changes) =>
              onNodesChange(changes.filter((c) => c.type !== "select"))
            }
            onNodeClick={(_, n) =>
              choose({ type: n.id === "issue" ? "issue" : "concept", id: n.id })
            }
            onEdgeClick={(_, e) => choose({ type: "relation", id: e.id })}
            onNodeMouseEnter={(_, node) =>
              preview.enter({
                type: node.id === "issue" ? "issue" : "concept",
                id: node.id,
              })
            }
            onNodeMouseLeave={preview.leave}
            onEdgeMouseEnter={(_, edge) =>
              preview.enter({ type: "relation", id: edge.id })
            }
            onEdgeMouseLeave={preview.leave}
            onNodeDragStart={preview.suspend}
            onNodeDragStop={preview.suspend}
            onMoveStart={preview.suspend}
            onMoveEnd={(_, v) => onViewport(v)}
            onPaneClick={() => {}}
            fitView
            fitViewOptions={{
              padding: {
                top: "150px",
                bottom: "80px",
                left: "40px",
                right: "40px",
              },
            }}
            minZoom={0.12}
            maxZoom={2}
            nodesConnectable={false}
            deleteKeyCode={null}
            selectionKeyCode={null}
            multiSelectionKeyCode={null}
            ariaLabelConfig={{
              "node.a11yDescription.default": "回车探索，方向键移动关键词。",
              "edge.a11yDescription.default": "回车探索关系。",
            }}
          >
            <Panel position="bottom-left" className="map-controls">
              <button onClick={() => void zoomOut()} aria-label="缩小画布">
                <Minus size={15} />
              </button>
              <span data-testid="zoom-level">{Math.round(zoom * 100)}%</span>
              <button onClick={() => void zoomIn()} aria-label="放大画布">
                <Plus size={15} />
              </button>
              <i />
              <button onClick={applyCamera} aria-label="聚焦当前关联">
                <Focus size={16} />
              </button>
            </Panel>
          </ReactFlow>
          <HoverPreview preview={preview.preview} relations={relations} />
        </div>
      </PreviewContext.Provider>
    </SelectionContext.Provider>
  );
}
