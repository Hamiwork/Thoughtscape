import { useRef, type FormEvent } from "react";
import { ArrowRight, CornerDownLeft, LoaderCircle } from "lucide-react";
import type { AIStatus } from "../hooks/useGeneration";
import { AIConnectionGuide } from "./AIConnectionGuide";
import {
  presetQuestions,
  matchingPresets,
  type PresetQuestion,
} from "../data/presets";
interface Props {
  value: string;
  onChange: (value: string) => void;
  onExplore: (question: string) => void;
  onPreset: (preset: PresetQuestion) => void;
  busy: boolean;
  error: string;
  status: AIStatus | null;
  canResume: boolean;
  onCancel: () => void;
}
export function QuestionEntry({
  value,
  onChange,
  onExplore,
  onPreset,
  busy,
  error,
  status,
  canResume,
  onCancel,
}: Props) {
  const guideRef = useRef<HTMLDetailsElement>(null);
  const matches = value.trim() ? matchingPresets(value) : presetQuestions;
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!busy && value.trim()) onExplore(value.trim());
  };
  return (
    <div className="question-entry">
      <header className="entry-header">
        <span className="brand">
          <span className="brand-symbol">✳</span>Thoughtscape
          <small>v0.5.0</small>
        </span>
        <span className="entry-edition">
          一张问题的思想地图 <i />
          01 / 起点
        </span>
      </header>
      <main className="entry-main preset-entry">
        <div className="entry-intro">
          <span className="entry-index">从提问，到理解</span>
          <h1>
            每一个好问题，
            <br />
            都有不止一条思路<span>。</span>
          </h1>
          <p>
            选择一个想理解的问题。
            <br />
            从关键词出发，看见关系、分歧与条件。
          </p>
        </div>
        <form className="question-form" onSubmit={submit}>
          <label htmlFor="exploration-question">
            <span>你想理解什么？</span>
            <small>问题 / 001</small>
          </label>
          <textarea
            id="exploration-question"
            value={value}
            onChange={(event) => onChange(event.target.value)}
            placeholder={
              status?.enabled && status.configured
                ? "输入你想探索的问题……"
                : "输入问题，或搜索演示主题；自定义问题需先接入自己的 AI"
            }
            maxLength={300}
            rows={2}
            disabled={busy}
            autoFocus
            aria-describedby="entry-demo-notice"
            onKeyDown={(event) => {
              if (
                event.key === "Enter" &&
                (event.metaKey || event.ctrlKey) &&
                !event.nativeEvent.isComposing
              ) {
                event.preventDefault();
                if (!busy && value.trim()) onExplore(value.trim());
              }
            }}
          />
          <div className="question-form-bottom">
            <span>
              <CornerDownLeft size={13} />
              Ctrl / ⌘ + Enter
            </span>
            <button
              className="enter-map"
              type="submit"
              disabled={busy || !value.trim()}
            >
              {busy ? (
                <>
                  <LoaderCircle className="generating-spinner" size={16} />
                  正在构建地图
                </>
              ) : (
                <>
                  {canResume
                    ? "继续探索"
                    : status?.enabled && status.configured
                      ? "探索问题"
                      : "进入演示地图"}
                  <ArrowRight size={17} />
                </>
              )}
            </button>
          </div>
          <p id="entry-demo-notice" className="entry-demo-notice">
            {status?.enabled && status.configured ? (
              `已由使用者接入 ${status.model}；自定义问题会调用该服务，内容仍需核实。`
            ) : (
              <>
                自定义问题需先
                <button
                  type="button"
                  className="inline-ai-connect"
                  aria-controls="ai-connection-guide"
                  onClick={() => {
                    const guide = guideRef.current;
                    if (!guide) return;
                    guide.open = true;
                    guide
                      .querySelector("summary")
                      ?.focus({ preventScroll: true });
                    guide.scrollIntoView({
                      block: "start",
                      behavior: window.matchMedia(
                        "(prefers-reduced-motion: reduce)",
                      ).matches
                        ? "instant"
                        : "smooth",
                    });
                  }}
                >
                  接入自己的 AI ↗
                </button>
                。<span>也可直接探索下方演示议题，无需接入 AI。</span>
                <small className="entry-source-note">
                  预置内容为演示假设，待核实；预置地图不产生 API 费用。
                </small>
              </>
            )}
          </p>
          {busy && (
            <div className="generation-feedback" role="status">
              <span>正在整理关键词与关系。</span>
              <button type="button" onClick={onCancel}>
                取消生成
              </button>
            </div>
          )}
          {error && (
            <p className="generation-error" role="status">
              {error}
            </p>
          )}
        </form>
        <section className="preset-library" aria-label="演示问题">
          <header>
            <span>选择一条探索的线索</span>
            <small>
              {presetQuestions.length} 个预置议题 / 演示假设，待核实
            </small>
          </header>
          <div className="preset-options">
            {presetQuestions.map((preset, index) => (
              <button
                type="button"
                key={preset.id}
                disabled={busy}
                className={
                  value.trim() && matches.includes(preset) ? "match" : ""
                }
                onClick={() => onPreset(preset)}
              >
                <span className="preset-number">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <span>
                  <strong>{preset.name}</strong>
                  <small>{preset.question}</small>
                </span>
                <ArrowRight size={14} />
              </button>
            ))}
          </div>
        </section>
        <AIConnectionGuide
          enabled={status?.enabled ?? false}
          detailsRef={guideRef}
        />
      </main>
      <footer className="entry-footer">
        <span>Explore the thinking behind complex questions.</span>
        <span>先看见不同思路，再形成自己的判断。</span>
      </footer>
    </div>
  );
}
