import { createContext } from "react";
import type { MapPreview } from "../types/knowledge";
export const PreviewContext = createContext<{
  enter: (next: MapPreview, keyboard?: boolean) => void;
  leave: () => void;
}>({ enter: () => {}, leave: () => {} });
