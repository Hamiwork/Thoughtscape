import { useKnowledge } from "../context/KnowledgeContext";
import type { Selection } from "../types/knowledge";
export function EvidenceButton({
  id,
  onSelect,
}: {
  id: string;
  onSelect: (s: Selection) => void;
}) {
  const { evidenceById, sourceById } = useKnowledge();
  const e = evidenceById[id];
  return (
    <button
      className="evidence-button"
      onClick={() => onSelect({ type: "evidence", id })}
    >
      <small>材料 {sourceById[e.sourceId].code} · 构造情景</small>
      <span>
        {e.label}
        <b>↗</b>
      </span>
    </button>
  );
}
export function EvidenceDetails({
  id,
  onSelect,
}: {
  id: string;
  onSelect: (s: Selection) => void;
}) {
  const { evidenceById, sourceById, conceptById, dataNotice } = useKnowledge();
  const e = evidenceById[id],
    s = sourceById[e.sourceId];
  return (
    <>
      <span className="panel-kicker">
        证据 / {s.code} · {dataNotice}
      </span>
      <h2>{e.label}</h2>
      <div className="provenance-banner">构造情景片段 · 非真实引文</div>
      <blockquote className="excerpt" data-testid="evidence-excerpt">
        {e.excerpt}
      </blockquote>
      <section>
        <h3>产品据此提出的判断</h3>
        <p>{e.judgment}</p>
      </section>
      <section>
        <h3>局限与适用范围</h3>
        <p>{e.limitation}</p>
      </section>
      <button
        className="source-link"
        onClick={() => onSelect({ type: "source", id: s.id })}
      >
        查看来源：{s.title} ↗
      </button>
      <section>
        <h3>这段材料关联的概念</h3>
        <div className="keyword-links">
          {e.conceptIds.map((id) => (
            <button key={id} onClick={() => onSelect({ type: "concept", id })}>
              {conceptById[id].name} ↗
            </button>
          ))}
        </div>
      </section>
    </>
  );
}
export function SourceDetails({
  id,
  onSelect,
}: {
  id: string;
  onSelect: (s: Selection) => void;
}) {
  const { sourceById, evidence, dataNotice } = useKnowledge();
  const s = sourceById[id];
  return (
    <>
      <span className="panel-kicker">来源材料 / {s.code}</span>
      <h2>{s.title}</h2>
      <div className="provenance-banner">{dataNotice} · 产品设计构造材料</div>
      <p>{s.description}</p>
      <dl className="source-facts">
        <div>
          <dt>来源类型</dt>
          <dd>模拟情景，非真实文章或研究</dd>
        </div>
        <div>
          <dt>作者 / 机构</dt>
          <dd>未指定，不冒充真实作者</dd>
        </div>
        <div>
          <dt>可验证地址</dt>
          <dd>暂无，尚未检索核实外部来源</dd>
        </div>
        <div>
          <dt>事实边界</dt>
          <dd>只能说明演示内部逻辑，不能作为实证结论</dd>
        </div>
      </dl>
      {evidence
        .filter((e) => e.sourceId === id)
        .map((e) => (
          <section key={e.id}>
            <h3>构造情景原始片段</h3>
            <blockquote className="excerpt">{e.excerpt}</blockquote>
            <EvidenceButton id={e.id} onSelect={onSelect} />
          </section>
        ))}
    </>
  );
}
