import { useEffect, useState } from "react";
import { useKnowledge } from "../context/KnowledgeContext";
import type { Concept, StanceFilter, StanceId } from "../types/knowledge";
export function StanceBadges({ ids }: { ids: StanceId[] }) {
  const { stances } = useKnowledge();
  return (
    <div className="stance-badges">
      {ids.length ? (
        ids.map((id) => (
          <span key={id} className={`stance-${id}`}>
            <b>{stances[id].symbol}</b>
            {stances[id].label}
          </span>
        ))
      ) : (
        <span>未标注立场</span>
      )}
    </div>
  );
}
export function StanceFilterBar({
  value,
  onChange,
}: {
  value: StanceFilter;
  onChange: (s: StanceFilter) => void;
}) {
  const { stances } = useKnowledge();
  return (
    <div className="stance-filter" role="group" aria-label="立场探索视角">
      <span>探索视角</span>
      <button aria-pressed={value === "all"} onClick={() => onChange("all")}>
        全部
      </button>
      {(Object.keys(stances) as StanceId[]).map((id) => (
        <button
          key={id}
          className={`stance-${id}`}
          aria-pressed={value === id}
          onClick={() => onChange(id)}
        >
          <b>{stances[id].symbol}</b>
          {stances[id].label}
        </button>
      ))}
    </div>
  );
}
export function StanceEditor({
  concept,
  onSave,
}: {
  concept: Concept;
  onSave: (ids: StanceId[]) => void;
}) {
  const { stances } = useKnowledge();
  const [draft, setDraft] = useState(concept.stanceIds);
  useEffect(() => {
    setDraft(concept.stanceIds);
  }, [concept]);
  const dirty =
    JSON.stringify([...draft].sort()) !==
    JSON.stringify([...concept.stanceIds].sort());
  return (
    <details className="stance-editor">
      <summary>修改此关键词的立场关联</summary>
      <p>
        这是你的探索标注，不是关键词的固有属性；可多选或全部取消。材料原本的论证立场保持不变。
      </p>
      {(Object.keys(stances) as StanceId[]).map((id) => (
        <label key={id}>
          <input
            type="checkbox"
            checked={draft.includes(id)}
            onChange={(e) =>
              setDraft(
                e.target.checked
                  ? [...draft, id]
                  : draft.filter((x) => x !== id),
              )
            }
          />
          {stances[id].symbol} {stances[id].label}
        </label>
      ))}
      <button
        className="text-action"
        disabled={!dirty}
        onClick={() => onSave(draft)}
      >
        应用立场标注 →
      </button>
    </details>
  );
}
