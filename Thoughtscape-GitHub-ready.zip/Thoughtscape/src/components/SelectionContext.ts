import { createContext } from "react";
import type { Selection } from "../types/knowledge";
export const SelectionContext = createContext<(selection: Selection) => void>(
  () => {},
);
