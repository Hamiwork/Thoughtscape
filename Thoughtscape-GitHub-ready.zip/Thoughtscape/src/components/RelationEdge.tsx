import { useContext } from "react";
import {
  BaseEdge,
  EdgeLabelRenderer,
  getBezierPath,
  type EdgeProps,
} from "@xyflow/react";
import type { MapEdge } from "../types/knowledge";
import { relationMeta } from "../data/relations";
import { PreviewContext } from "./PreviewContext";
import { SelectionContext } from "./SelectionContext";
export function RelationEdge(props: EdgeProps<MapEdge>) {
  const select = useContext(SelectionContext);
  const preview = useContext(PreviewContext);
  const {
    id,
    sourceX: sx,
    sourceY: sy,
    targetX: tx,
    targetY: ty,
    sourcePosition,
    targetPosition,
    data,
    markerEnd,
  } = props;
  const r = data!.relation,
    m = relationMeta[r.assessment.kind];
  let [path, x, y] = getBezierPath({
    sourceX: sx,
    sourceY: sy,
    targetX: tx,
    targetY: ty,
    sourcePosition,
    targetPosition,
    curvature: 0.22,
  });
  if (r.route === "upper-corridor") {
    const lane = Math.min(sy, ty) - 60;
    path = `M${sx},${sy} C${sx + 35},${sy} ${sx + 30},${lane} ${sx + 95},${lane} L${tx - 95},${lane} C${tx - 30},${lane} ${tx - 35},${ty} ${tx},${ty}`;
    x = (sx + tx) / 2;
    y = lane;
  }
  if (r.route === "left-corridor") {
    const lane = Math.min(sx, tx) + 22;
    path = `M${sx},${sy} C${lane + 55},${sy} ${lane},${sy} ${lane},${sy - 35} L${lane},${ty + 35} Q${lane},${ty} ${tx},${ty}`;
    x = lane - 10;
    y = (sy + ty) / 2;
  }
  return (
    <>
      <BaseEdge
        id={id}
        path={path}
        markerEnd={markerEnd}
        interactionWidth={18}
        style={{
          stroke: m.color,
          strokeDasharray: m.dash,
          strokeWidth: data!.active ? 1.9 : 1,
          opacity: data!.muted ? 0.12 : data!.active ? 1 : 0.43,
        }}
      />
      <EdgeLabelRenderer>
        <button
          data-testid={`relation-${id}`}
          data-kind={r.assessment.kind}
          data-cross-stance={data!.crossStance}
          data-label={r.assessment.label}
          data-previewed={!!data!.previewed}
          onMouseEnter={() => preview.enter({ type: "relation", id })}
          onMouseLeave={preview.leave}
          onFocus={() => preview.enter({ type: "relation", id }, true)}
          onBlur={preview.leave}
          className={`edge-label nodrag nopan ${data!.showLabel ? "revealed" : "quiet"} ${data!.active ? "active" : ""} ${data!.muted ? "muted" : ""}`}
          style={{
            transform: `translate(-50%,-50%) translate(${x}px,${y}px)`,
            color: m.color,
          }}
          aria-label={`探索关系：${r.assessment.label}（${id}）`}
          onClick={() => select({ type: "relation", id })}
        >
          {data!.showLabel ? (
            <>
              {r.assessment.origin === "user" && <i />}
              {r.assessment.label}
              <span>{m.symbol}</span>
            </>
          ) : (
            <span className="edge-dot" />
          )}
        </button>
      </EdgeLabelRenderer>
    </>
  );
}
