import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ReactFlowProvider, type Viewport } from "@xyflow/react";
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  Check,
  ChevronRight,
  CircleHelp,
  Search,
  RotateCcw,
  Undo2,
  X,
} from "lucide-react";
import { useKnowledge } from "./context/KnowledgeContext";
import { neighborhood } from "./domain/exploration";
import { MapCanvas } from "./components/MapCanvas";
import { DetailPanel } from "./components/DetailPanel";
import { SourceLibrary } from "./components/SourceLibrary";
import { HelpDialog } from "./components/HelpDialog";
import { StanceFilterBar } from "./components/StanceControls";
import { useRelations } from "./hooks/useRelations";
import type {
  CameraRequest,
  ExplorationStep,
  Selection,
  StanceFilter,
} from "./types/knowledge";
export default function ThoughtscapeWorkspace({
  question,
  onEditQuestion,
}: {
  question: string;
  onEditQuestion: () => void;
}) {
  const {
    issue,
    conceptById,
    claimById,
    evidenceById,
    evidence,
    sources,
    sourceById,
    dataNotice,
    mode,
  } = useKnowledge();
  const model = useRelations();
  const startConcept =
    model.concepts.find((c) => c.id === "complaint") ??
    model.concepts.find((c) => c.level === "primary") ??
    model.concepts[0];
  const [history, setHistory] = useState<ExplorationStep[]>([
    { selection: null },
  ]);
  const [stance, setStance] = useState<StanceFilter>("all"),
    [depth, setDepth] = useState(1),
    [resetKey, setResetKey] = useState(0),
    [camera, setCamera] = useState<CameraRequest | null>(null);
  const [searchOpen, setSearchOpen] = useState(false),
    [query, setQuery] = useState(""),
    [libraryOpen, setLibraryOpen] = useState(false),
    [helpOpen, setHelpOpen] = useState(false);
  const viewport = useRef<Viewport>({ x: 0, y: 0, zoom: 1 });
  const selection = history.at(-1)!.selection;
  const contextIds = useCallback(
    (s: Selection): string[] => {
      if (!s) return [];
      switch (s.type) {
        case "concept":
          return [...neighborhood(s.id, model.relations)];
        case "relation": {
          const r = model.relations.find((r) => r.id === s.id)!;
          return [r.sourceId, r.targetId];
        }
        case "evidence":
          return evidenceById[s.id].conceptIds;
        case "source":
          return [
            ...new Set(
              evidence
                .filter((e) => e.sourceId === s.id)
                .flatMap((e) => e.conceptIds),
            ),
          ];
        case "claim":
          return claimById[s.id].conceptIds;
        default:
          return ["issue"];
      }
    },
    [model.relations],
  );
  const select = useCallback(
    (next: Selection) => {
      setHistory((previous) => {
        const last = previous.at(-1)!;
        if (
          last.selection?.type === next?.type &&
          last.selection?.id === next?.id
        )
          return previous;
        return [
          ...previous.slice(0, -1),
          { ...last, viewport: viewport.current },
          { selection: next },
        ].slice(-30);
      });
      setCamera({ token: Date.now(), ids: contextIds(next) });
      setDepth(1);
      setSearchOpen(false);
      setLibraryOpen(false);
    },
    [contextIds],
  );
  const back = () => {
    if (history.length < 2) return;
    const previous = history.at(-2)!;
    setHistory((h) => h.slice(0, -1));
    setDepth(1);
    setCamera({
      token: Date.now(),
      viewport: previous.viewport,
      ids: contextIds(previous.selection),
    });
  };
  const global = () => {
    select(null);
    setStance("all");
    setCamera({ token: Date.now(), ids: [] });
  };
  const resetView = () => {
    setHistory([{ selection: null }]);
    setStance("all");
    setDepth(1);
    setCamera({ token: Date.now(), ids: [] });
    setResetKey((k) => k + 1);
    setSearchOpen(false);
    setLibraryOpen(false);
  };
  const changeStance = (next: StanceFilter) => {
    setStance(next);
    if (selection) {
      setHistory((h) => [
        ...h.slice(0, -1),
        { ...h.at(-1)!, viewport: viewport.current },
        { selection: null },
      ]);
      setCamera({ token: Date.now(), viewport: viewport.current });
    }
    setDepth(1);
  };
  useEffect(() => {
    if (!model.notice) return;
    const timer = setTimeout(
      () => model.dispatch({ type: "clear-notice" }),
      4500,
    );
    return () => clearTimeout(timer);
  }, [model.notice]);
  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !helpOpen) {
        if (libraryOpen) setLibraryOpen(false);
        else if (searchOpen) setSearchOpen(false);
        else if (selection) global();
      }
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, [helpOpen, libraryOpen, searchOpen, selection]);
  const activeIds = useMemo(
    () =>
      new Set(
        selection?.type === "concept"
          ? [selection.id]
          : selection?.type === "relation"
            ? contextIds(selection)
            : selection?.type === "issue"
              ? ["issue"]
              : [],
      ),
    [selection, contextIds],
  );
  const spotlight = useMemo(
    () =>
      !selection
        ? null
        : selection.type === "concept"
          ? neighborhood(selection.id, model.relations, depth)
          : selection.type === "issue"
            ? null
            : new Set(contextIds(selection)),
    [selection, model.relations, depth, contextIds],
  );
  const recent = [
    ...new Set(
      history
        .filter((h) => h.selection?.type === "concept")
        .map((h) => h.selection!.id)
        .reverse(),
    ),
  ]
    .slice(0, 5)
    .reverse();
  const currentLabel = selection
    ? selection.type === "concept"
      ? conceptById[selection.id].name
      : selection.type === "relation"
        ? "关系分析"
        : selection.type === "evidence"
          ? "证据检查"
          : selection.type === "source"
            ? sourceById[selection.id].title
            : selection.type === "claim"
              ? "观点检查"
              : "议题"
    : "";
  return (
    <div className="app-shell">
      <header className="topbar">
        <a
          className="brand"
          href="#"
          onClick={(e) => {
            e.preventDefault();
            onEditQuestion();
          }}
          aria-label="Thoughtscape 首页"
        >
          <span className="brand-symbol">✳</span>Thoughtscape
          <small>v0.5.0</small>
        </a>
        <span className="brand-purpose">从关键词出发，沿关系追问</span>
        <div className="top-actions">
          <button onClick={onEditQuestion} aria-label="返回修改问题">
            <ArrowLeft size={15} />
            <span>修改问题</span>
          </button>
          <button
            onClick={() => {
              setSearchOpen((v) => !v);
              setLibraryOpen(false);
            }}
            aria-expanded={searchOpen}
            aria-label="查找关键词"
          >
            <Search size={15} />
            <span>关键词</span>
          </button>
          <button
            onClick={() => {
              setLibraryOpen((v) => !v);
              setSearchOpen(false);
            }}
            aria-label="查看来源材料"
          >
            <BookOpen size={15} />
            <span>材料 {String(sources.length).padStart(2, "0")}</span>
          </button>
          {model.modifiedCount > 0 && (
            <span className="modified-count">已修改 {model.modifiedCount}</span>
          )}
          {model.canUndo && (
            <button
              onClick={() => model.dispatch({ type: "undo" })}
              aria-label="撤销最近一次修改"
            >
              <Undo2 size={16} />
            </button>
          )}
          <button
            onClick={resetView}
            aria-label="重置视图"
            title="恢复节点布局，保留你的关系和立场标注"
          >
            <RotateCcw size={15} />
            <span>重置视图</span>
          </button>
          <button onClick={() => setHelpOpen(true)} aria-label="探索指南">
            <CircleHelp size={16} />
          </button>
        </div>
      </header>
      <div
        className={`question-context ${mode === "ai" ? "custom-question" : ""}`}
      >
        <span className="question-context-label">你的问题</span>
        <span className="question-context-text" title={question}>
          {question}
        </span>
        <small>{mode === "ai" ? "AI 生成 · 尚未核实" : "预置演示地图"}</small>
      </div>
      <main
        className={`canvas-stage ${selection ? "with-detail" : ""}`}
        aria-label={issue.question}
      >
        <div className="canvas-heading">
          <div>
            <span className="eyebrow">
              议题 001 / 关键词网络 <i />
              {mode === "ai"
                ? "概念、分歧与成立条件"
                : "独立议题 · 多个探索视角"}
            </span>
            <h1>{issue.question}</h1>
          </div>
          <small className="archive-meta">
            {model.concepts.length} 个关键词 / {model.relations.length}{" "}
            条语义关系
          </small>
        </div>
        <StanceFilterBar value={stance} onChange={changeStance} />
        <div className="map-frame">
          <ReactFlowProvider>
            <MapCanvas
              concepts={model.concepts}
              relations={model.relations}
              selection={selection}
              onSelect={select}
              stance={stance}
              spotlight={spotlight}
              activeIds={activeIds}
              camera={camera}
              onViewport={(v) => {
                viewport.current = v;
              }}
              resetKey={resetKey}
            />
          </ReactFlowProvider>
        </div>
        <nav className="exploration-trail" aria-label="探索历史">
          <button
            onClick={back}
            disabled={history.length < 2}
            aria-label="返回上一个探索位置"
          >
            <ArrowLeft size={13} />
          </button>
          <button onClick={global}>全局地图</button>
          {recent.map((id, i) => (
            <span key={id}>
              <ChevronRight size={11} />
              <button
                className={selection?.id === id ? "current" : ""}
                onClick={() => select({ type: "concept", id })}
              >
                {conceptById[id].name}
              </button>
              {i === recent.length - 1 &&
                selection &&
                selection.type !== "concept" && (
                  <small> / {currentLabel}</small>
                )}
            </span>
          ))}
          {depth > 1 && <small>已展开 {depth} 步关联</small>}
        </nav>
        {!selection && (
          <div className="start-clue">
            <span>悬停预览，单击深入。</span>
            <button
              onClick={() => select({ type: "concept", id: startConcept.id })}
            >
              从「{startConcept.name}」开始 <ArrowRight size={14} />
            </button>
          </div>
        )}
        <div className="canvas-caption">
          <span>＋ 支持　− 质疑　◇ 条件</span>
          <small>悬停放大预览 · 单击固定探索 · 沿关系继续。</small>
        </div>
        <DetailPanel
          selection={selection}
          concepts={model.concepts}
          relations={model.relations}
          onSelect={select}
          onBack={back}
          canBack={history.length > 1}
          onFocus={(ids) => setCamera({ token: Date.now(), ids })}
          depth={depth}
          onDepth={setDepth}
          dispatch={model.dispatch}
          canUndo={model.canUndo}
        />
        {searchOpen && (
          <aside className="keyword-finder" aria-label="关键词查找">
            <header>
              <span>从任何概念出发</span>
              <button
                onClick={() => setSearchOpen(false)}
                aria-label="关闭关键词查找"
              >
                <X size={16} />
              </button>
            </header>
            <input
              aria-label="搜索关键词"
              placeholder="输入地图中的关键词"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              autoFocus
            />
            <div className="finder-results">
              {model.concepts
                .filter((c) => c.name.includes(query.trim()))
                .map((c) => (
                  <button
                    key={c.id}
                    onClick={() => select({ type: "concept", id: c.id })}
                  >
                    {c.name}
                    <ArrowRight size={12} />
                  </button>
                ))}
            </div>
            {!model.concepts.some((c) => c.name.includes(query.trim())) && (
              <p>没有找到这个词。试试更短的关键词。</p>
            )}
            <button
              className="restore-data"
              onClick={() => {
                model.dispatch({ type: "restore" });
                setStance("all");
              }}
            >
              恢复初始数据（关系与立场）
            </button>
            <small>不会清除节点位置；刷新页面会清除当前会话。</small>
          </aside>
        )}
        {libraryOpen && (
          <div
            className="library-backdrop"
            onClick={() => setLibraryOpen(false)}
          >
            <div onClick={(e) => e.stopPropagation()}>
              <SourceLibrary
                onSelect={select}
                onClose={() => setLibraryOpen(false)}
              />
            </div>
          </div>
        )}
        {model.notice && (
          <div className="notice" role="status">
            <Check size={14} />
            <span>{model.notice}</span>
            <button
              onClick={() => model.dispatch({ type: "clear-notice" })}
              aria-label="关闭提示"
            >
              <X size={13} />
            </button>
          </div>
        )}
      </main>
      <footer className="workspace-footer">
        <span>
          <i />
          {dataNotice}
        </span>
        <span>关键词不是结论 · 连线需要依据 · 理解可以改写</span>
        <span>Explore the thinking behind complex questions.</span>
      </footer>
      {helpOpen && <HelpDialog onClose={() => setHelpOpen(false)} />}
    </div>
  );
}
