import { lazy, Suspense, useState } from "react";
import { QuestionEntry } from "./components/QuestionEntry";
const ThoughtscapeWorkspace = lazy(() => import("./ThoughtscapeWorkspace"));
import { KnowledgeProvider } from "./context/KnowledgeContext";
import { useGeneration } from "./hooks/useGeneration";
import { matchingPresets, type PresetQuestion } from "./data/presets";
import type { KnowledgeDataset } from "./types/knowledge";

export default function App() {
  const [draft, setDraft] = useState("");
  const [session, setSession] = useState<{
    data: KnowledgeDataset;
    key: number;
  } | null>(null);
  const [screen, setScreen] = useState<"question" | "map">("question");
  const [message, setMessage] = useState("");
  const ai = useGeneration();
  const canResume = !!session && draft.trim() === session.data.issue.question;
  const openPreset = (preset: PresetQuestion) => {
    setDraft(preset.question);
    setMessage("");
    ai.clearError();
    if (session?.data !== preset.data)
      setSession({ data: preset.data, key: Date.now() });
    setScreen("map");
  };
  const explore = async (question: string) => {
    if (canResume) {
      setScreen("map");
      return;
    }
    const matches = matchingPresets(question);
    if (matches.length === 1) {
      openPreset(matches[0]);
      return;
    }
    if (ai.status?.enabled && ai.status.configured) {
      const data = await ai.generate(question);
      if (data) {
        setSession({ data, key: Date.now() });
        setScreen("map");
      }
      return;
    }
    setMessage(
      matches.length > 1
        ? "找到了几个相关议题，请从下方选择一个。"
        : "暂时没有这个问题的演示地图。请选择下方议题，或搜索「写作」「远程」「交通」等关键词。",
    );
  };
  return (
    <>
      {screen === "question" && (
        <QuestionEntry
          value={draft}
          onChange={(value) => {
            setDraft(value);
            setMessage("");
            ai.clearError();
          }}
          onExplore={explore}
          onPreset={openPreset}
          busy={ai.busy}
          error={ai.error || message}
          status={ai.status}
          canResume={canResume}
          onCancel={ai.cancel}
        />
      )}
      {session && (
        <div className="workspace-screen" hidden={screen !== "map"}>
          <KnowledgeProvider key={session.key} data={session.data}>
            <Suspense
              fallback={
                <div className="map-loading" role="status">
                  正在打开知识地图…
                </div>
              }
            >
              <ThoughtscapeWorkspace
                question={session.data.issue.question}
                onEditQuestion={() => setScreen("question")}
              />
            </Suspense>
          </KnowledgeProvider>
        </div>
      )}
    </>
  );
}
