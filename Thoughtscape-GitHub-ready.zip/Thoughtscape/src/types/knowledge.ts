import type { Node, Edge, Viewport } from "@xyflow/react";
export type StanceId = "automation" | "challenge" | "conditional";
export type StanceFilter = "all" | StanceId;
export type RelationKind =
  | "promotes"
  | "suitable"
  | "needs"
  | "influences"
  | "risk"
  | "tradeoff"
  | "conditional"
  | "handoff"
  | "complement"
  | "conflict"
  | "uncertain";
export type Verification = "demo-hypothesis" | "ai-unverified";
export interface Issue {
  id: string;
  name: string;
  question: string;
  explanation: string;
}
export interface Concept {
  id: string;
  name: string;
  type: "concept" | "condition";
  topicId: string;
  explanation: string;
  level: "primary" | "secondary";
  stanceIds: StanceId[];
  evidenceIds: string[];
  position: { x: number; y: number };
}
export interface Claim {
  id: string;
  type: "claim";
  text: string;
  stanceId: StanceId;
  conceptIds: string[];
  evidenceIds: string[];
  conditions: string[];
}
export interface Source {
  id: string;
  type: "source";
  code: string;
  title: string;
  sourceType: "constructed-scenario";
  author: null;
  url: null;
  verification: Verification;
  description: string;
}
export interface Evidence {
  id: string;
  type: "evidence";
  sourceId: string;
  label: string;
  excerpt: string;
  excerptType: "constructed";
  judgment: string;
  limitation: string;
  conceptIds: string[];
  relationIds: string[];
  verification: Verification;
}
export interface RelationAssessment {
  kind: RelationKind;
  label: string;
  reason: string;
  origin: "demo" | "ai" | "user";
}
export interface Relation {
  id: string;
  sourceId: string;
  targetId: string;
  type: "relation";
  assessment: RelationAssessment;
  conditions: string[];
  uncertainty: string;
  evidenceIds: string[];
  sourceIds: string[];
  claimIds: string[];
  verification: Verification;
  featured: boolean;
  route?: "upper-corridor" | "left-corridor";
}
export type Selection = {
  type: "concept" | "relation" | "claim" | "evidence" | "source" | "issue";
  id: string;
} | null;
export type MapPreview = { type: "concept" | "relation" | "issue"; id: string };
export interface CameraRequest {
  token: number;
  ids?: string[];
  viewport?: Viewport;
}
export type MapNode = Node<
  {
    name: string;
    objectType: "concept" | "condition" | "issue";
    number: string;
    level: "primary" | "secondary";
    stanceIds: StanceId[];
    muted: boolean;
    selected: boolean;
    related: boolean;
    previewed?: boolean;
    bridge?: boolean;
    overview?: boolean;
    previewScale?: number;
  },
  "knowledge"
>;
export type MapEdge = Edge<{
  relation: Relation;
  active: boolean;
  showLabel: boolean;
  muted: boolean;
  crossStance: boolean;
  previewed?: boolean;
}>;
export interface ExplorationStep {
  selection: Selection;
  viewport?: Viewport;
}
export type ModelChange =
  | { type: "relation"; id: string; before: RelationAssessment }
  | { type: "stance"; id: string; before: StanceId[] };

export interface KnowledgeDataset {
  mode: "demo" | "ai";
  issue: Issue;
  issuePosition?: { x: number; y: number };
  concepts: Concept[];
  relations: Relation[];
  claims: Claim[];
  evidence: Evidence[];
  sources: Source[];
  stances: Record<
    StanceId,
    {
      label: string;
      short: string;
      symbol: string;
      color: string;
      description: string;
    }
  >;
  dataNotice: string;
  generation?: { model: string; generatedAt: string };
}
