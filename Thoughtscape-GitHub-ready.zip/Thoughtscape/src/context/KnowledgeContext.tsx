import { createContext, useContext, useMemo, type ReactNode } from "react";
import * as demo from "../data/demo";
import type { KnowledgeDataset } from "../types/knowledge";

export const demoDataset: KnowledgeDataset = {
  mode: "demo",
  issue: demo.issue,
  concepts: demo.concepts,
  relations: demo.relations,
  claims: demo.claims,
  evidence: demo.evidence,
  sources: demo.sources,
  stances: demo.stances,
  dataNotice: demo.dataNotice,
};

function indexDataset(data: KnowledgeDataset) {
  return {
    ...data,
    conceptById: Object.fromEntries(data.concepts.map((c) => [c.id, c])),
    claimById: Object.fromEntries(data.claims.map((c) => [c.id, c])),
    sourceById: Object.fromEntries(data.sources.map((s) => [s.id, s])),
    evidenceById: Object.fromEntries(data.evidence.map((e) => [e.id, e])),
  };
}
const KnowledgeContext = createContext(indexDataset(demoDataset));
export function KnowledgeProvider({
  data,
  children,
}: {
  data: KnowledgeDataset;
  children: ReactNode;
}) {
  const indexed = useMemo(() => indexDataset(data), [data]);
  return (
    <KnowledgeContext.Provider value={indexed}>
      {children}
    </KnowledgeContext.Provider>
  );
}
export const useKnowledge = () => useContext(KnowledgeContext);
