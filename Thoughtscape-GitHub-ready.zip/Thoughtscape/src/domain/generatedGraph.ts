import type {
  Claim,
  Concept,
  KnowledgeDataset,
  Relation,
  RelationKind,
  StanceId,
} from "../types/knowledge";

const kinds: RelationKind[] = [
  "promotes",
  "suitable",
  "needs",
  "influences",
  "risk",
  "tradeoff",
  "conditional",
  "handoff",
  "complement",
  "conflict",
  "uncertain",
];
const perspectives: StanceId[] = ["automation", "challenge", "conditional"];
type RecordValue = Record<string, unknown>;
function object(value: unknown): RecordValue {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new Error("地图对象格式不完整");
  return value as RecordValue;
}
function text(value: unknown, max: number, min = 1): string {
  if (
    typeof value !== "string" ||
    value.trim().length < min ||
    value.trim().length > max
  )
    throw new Error("地图文字长度不符合约定");
  return value.trim();
}
function list(value: unknown, min: number, max: number): unknown[] {
  if (!Array.isArray(value) || value.length < min || value.length > max)
    throw new Error("地图对象数量不符合约定");
  return value;
}
function strings(value: unknown, min = 1, max = 4): string[] {
  return list(value, min, max).map((v) => text(v, 160));
}
function ids(value: unknown, allowed: Set<string>, min = 1, max = 4): string[] {
  const result = strings(value, min, max);
  if (
    result.some((id) => !allowed.has(id)) ||
    new Set(result).size !== result.length
  )
    throw new Error("地图包含未知或重复引用");
  return result;
}

// Deterministic force layout: adjacent concepts cluster; a central title and
// text-sized collision boxes keep the map usable without a layout dependency.
function layout(concepts: Concept[], relations: Relation[]) {
  const points = concepts.map((c, i) => ({
    id: c.id,
    x: 650 + Math.cos(i * 2.39996) * (330 + (i % 3) * 75),
    y: 410 + Math.sin(i * 2.39996) * (240 + (i % 4) * 45),
  }));
  for (let step = 0; step < 350; step++) {
    const forces = points.map(() => ({ x: 0, y: 0 }));
    for (let i = 0; i < points.length; i++) {
      for (let j = i + 1; j < points.length; j++) {
        const dx = points[i].x - points[j].x,
          dy = points[i].y - points[j].y;
        const d = Math.max(1, Math.hypot(dx, dy));
        const f = Math.min(14, 19000 / (d * d));
        forces[i].x += (dx / d) * f;
        forces[i].y += (dy / d) * f;
        forces[j].x -= (dx / d) * f;
        forces[j].y -= (dy / d) * f;
      }
      const dx = points[i].x - 650,
        dy = points[i].y - 410,
        d = Math.max(1, Math.hypot(dx, dy));
      if (d < 240) {
        forces[i].x += (dx / d) * 9;
        forces[i].y += (dy / d) * 9;
      }
      forces[i].x -= dx * 0.004;
      forces[i].y -= dy * 0.004;
    }
    for (const relation of relations) {
      const a = points.findIndex((p) => p.id === relation.sourceId),
        b = points.findIndex((p) => p.id === relation.targetId);
      const dx = points[b].x - points[a].x,
        dy = points[b].y - points[a].y,
        d = Math.max(1, Math.hypot(dx, dy));
      const f = (d - 280) * 0.013;
      forces[a].x += (dx / d) * f;
      forces[a].y += (dy / d) * f;
      forces[b].x -= (dx / d) * f;
      forces[b].y -= (dy / d) * f;
    }
    points.forEach((p, i) => {
      p.x += forces[i].x;
      p.y += forces[i].y;
    });
  }
  const minX = Math.min(...points.map((p) => p.x)),
    maxX = Math.max(...points.map((p) => p.x));
  const minY = Math.min(...points.map((p) => p.y)),
    maxY = Math.max(...points.map((p) => p.y));
  points.forEach((p) => {
    p.x = ((p.x - minX) / Math.max(1, maxX - minX)) * 1320;
    p.y = ((p.y - minY) / Math.max(1, maxY - minY)) * 500;
  });
  // Resolve bounding-box overlaps, including the central issue, without moving
  // the whole graph after a selection or perspective change.
  const anchor = { id: "issue", x: 600, y: 250 };
  for (let step = 0; step < 120; step++) {
    for (let i = 0; i < points.length; i++) {
      for (const other of [...points.slice(i + 1), anchor]) {
        const p = points[i],
          dx = p.x - other.x,
          dy = p.y - other.y;
        if (Math.abs(dx) < 230 && Math.abs(dy) < 115) {
          const factor = other === anchor ? 1 : 0.51;
          if ((231 - Math.abs(dx)) / 230 < (116 - Math.abs(dy)) / 115) {
            const shift = (231 - Math.abs(dx)) * factor * (dx >= 0 ? 1 : -1);
            p.x += shift;
            if (other !== anchor) other.x -= shift;
          } else {
            const shift = (116 - Math.abs(dy)) * factor * (dy >= 0 ? 1 : -1);
            p.y += shift;
            if (other !== anchor) other.y -= shift;
          }
        }
      }
    }
  }
  concepts.forEach((c, i) => {
    c.position = { x: Math.round(points[i].x), y: Math.round(points[i].y) };
  });
}

export function normalizeGeneratedGraph(
  raw: unknown,
  question: string,
  model: string,
): KnowledgeDataset {
  const root = object(raw),
    view = object(root.perspectives);
  const rawConcepts = list(root.concepts, 10, 20).map(object);
  const rawClaims = list(root.claims, 4, 10).map(object);
  const rawRelations = list(root.relations, 10, 36).map(object);
  const uniqueIds = (rows: RecordValue[]) => {
    const result = rows.map((row) => text(row.id, 40));
    if (
      result.some((id) => !/^[a-z][a-z0-9_-]{0,39}$/.test(id)) ||
      new Set(result).size !== result.length ||
      result.includes("issue")
    )
      throw new Error("地图 ID 重复");
    return new Set(result);
  };
  const conceptIds = uniqueIds(rawConcepts),
    claimIds = uniqueIds(rawClaims);
  const allowedStances = new Set<string>(perspectives);
  if (
    rawConcepts.some(
      (c) =>
        !["concept", "condition"].includes(String(c.type)) ||
        !["primary", "secondary"].includes(String(c.level)),
    )
  )
    throw new Error("关键词类型无效");
  const concepts: Concept[] = rawConcepts.map((c) => ({
    id: text(c.id, 40),
    name: text(c.name, 12, 2),
    type: c.type === "condition" ? "condition" : "concept",
    topicId: "issue",
    explanation: text(c.explanation, 240),
    level: c.level === "primary" ? "primary" : "secondary",
    stanceIds: ids(c.stanceIds, allowedStances, 0, 3) as StanceId[],
    evidenceIds: [],
    position: { x: 0, y: 0 },
  }));
  if (
    new Set(concepts.map((c) => c.name)).size !== concepts.length ||
    !concepts.some((c) => c.level === "primary")
  )
    throw new Error("关键词重复或缺少主要概念");
  const claims: Claim[] = rawClaims.map((c) => ({
    id: text(c.id, 40),
    type: "claim",
    text: text(c.text, 300),
    stanceId: ids([c.stanceId], allowedStances)[0] as StanceId,
    conceptIds: ids(c.conceptIds, conceptIds, 1, 5),
    evidenceIds: [],
    conditions: strings(c.conditions),
  }));
  const seen = new Set<string>();
  const relations: Relation[] = rawRelations.map((r, i) => {
    const sourceId = text(r.sourceId, 40),
      targetId = text(r.targetId, 40);
    if (
      !conceptIds.has(sourceId) ||
      !conceptIds.has(targetId) ||
      sourceId === targetId
    )
      throw new Error("关系端点无效");
    const pair = [sourceId, targetId].sort().join("|");
    if (seen.has(pair)) throw new Error("关系重复");
    seen.add(pair);
    if (!kinds.includes(r.kind as RelationKind))
      throw new Error("关系类型无效");
    return {
      id: `r${String(i + 1).padStart(2, "0")}`,
      type: "relation",
      sourceId,
      targetId,
      assessment: {
        kind: r.kind as RelationKind,
        label: text(r.label, 12),
        reason: text(r.reason, 400, 8),
        origin: "ai",
      },
      conditions: strings(r.conditions),
      uncertainty: text(r.uncertainty, 300),
      evidenceIds: [],
      sourceIds: [],
      claimIds: ids(r.claimIds, claimIds, 1, 4),
      verification: "ai-unverified",
      featured: i % 3 === 0,
    };
  });
  const visited = new Set([concepts[0].id]);
  for (let step = 0; step < concepts.length; step++)
    for (const r of relations) {
      if (visited.has(r.sourceId)) visited.add(r.targetId);
      if (visited.has(r.targetId)) visited.add(r.sourceId);
    }
  if (visited.size !== concepts.length) throw new Error("地图包含孤立概念");
  layout(concepts, relations);
  const metadata = [
    { short: "支持", symbol: "＋", color: "#6b7868" },
    { short: "质疑", symbol: "−", color: "#802b38" },
    { short: "条件", symbol: "◇", color: "#957a4f" },
  ];
  return {
    mode: "ai",
    issue: {
      id: "issue",
      name: text(root.title, 12, 2),
      question,
      explanation: text(root.summary, 300),
    },
    issuePosition: { x: 600, y: 250 },
    concepts,
    claims,
    relations,
    evidence: [],
    sources: [],
    stances: Object.fromEntries(
      perspectives.map((id, i) => [
        id,
        {
          ...metadata[i],
          label: text(view[id], 12),
          description: "AI 生成的候选论证视角，允许多重关联，仍需人工判断。",
        },
      ]),
    ) as KnowledgeDataset["stances"],
    dataNotice: "AI 生成，未经来源核实",
    generation: { model, generatedAt: new Date().toISOString() },
  };
}
