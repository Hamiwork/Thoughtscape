import { concepts as initialConcepts } from "../data/entities.ts";
import { relations as initialRelations } from "../data/relations.ts";
import { stances } from "../data/stances.ts";
import type {
  Concept,
  ModelChange,
  Relation,
  RelationKind,
  StanceId,
} from "../types/knowledge";
export interface KnowledgeState {
  concepts: Concept[];
  relations: Relation[];
  history: ModelChange[];
  notice: string;
}
export type KnowledgeAction =
  | {
      type: "relation";
      id: string;
      kind: RelationKind;
      label: string;
      reason: string;
      confirmed: boolean;
    }
  | { type: "stance"; id: string; stanceIds: StanceId[] }
  | { type: "undo" | "restore" | "clear-notice" };
export const initialState: KnowledgeState = {
  concepts: initialConcepts,
  relations: initialRelations,
  history: [],
  notice: "",
};
export function validateAssessment(
  kind: RelationKind,
  label: string,
  reason: string,
  confirmed: boolean,
) {
  if (!label.trim() || label.trim().length > 12)
    return "请填写 1 至 12 字的关系标签。";
  if (reason.trim().length < 8) return "请用至少 8 个字说明判断依据。";
  if (kind === "conflict" && !confirmed)
    return "标记冲突前，请确认相同场景与评价标准。";
  return null;
}
export function knowledgeReducer(
  state: KnowledgeState,
  action: KnowledgeAction,
  baseline: KnowledgeState = initialState,
): KnowledgeState {
  if (action.type === "clear-notice") return { ...state, notice: "" };
  if (action.type === "restore")
    return { ...baseline, notice: "已恢复初始关系与立场标注。" };
  if (action.type === "undo") {
    const last = state.history.at(-1);
    if (!last) return state;
    return {
      ...state,
      history: state.history.slice(0, -1),
      relations:
        last.type === "relation"
          ? state.relations.map((r) =>
              r.id === last.id ? { ...r, assessment: last.before } : r,
            )
          : state.relations,
      concepts:
        last.type === "stance"
          ? state.concepts.map((c) =>
              c.id === last.id ? { ...c, stanceIds: last.before } : c,
            )
          : state.concepts,
      notice: "已撤销最近一次修改。",
    };
  }
  if (action.type === "stance") {
    const current = state.concepts.find((c) => c.id === action.id);
    if (!current) return state;
    const ids = [...new Set(action.stanceIds)].filter((id) => id in stances);
    if (
      ids.length === current.stanceIds.length &&
      ids.every((x) => current.stanceIds.includes(x))
    )
      return state;
    return {
      ...state,
      concepts: state.concepts.map((c) =>
        c.id === action.id ? { ...c, stanceIds: ids } : c,
      ),
      history: [
        ...state.history,
        { type: "stance", id: action.id, before: current.stanceIds },
      ],
      notice: "已更新你的立场标注；筛选与节点标记同步。",
    };
  }
  if (action.type !== "relation") return state;
  const relation = state.relations.find((r) => r.id === action.id);
  if (!relation) return state;
  const error = validateAssessment(
    action.kind,
    action.label,
    action.reason,
    action.confirmed,
  );
  if (error) return { ...state, notice: error };
  return {
    ...state,
    relations: state.relations.map((r) =>
      r.id === action.id
        ? {
            ...r,
            assessment: {
              kind: action.kind,
              label: action.label.trim(),
              reason: action.reason.trim(),
              origin: "user",
            },
          }
        : r,
    ),
    history: [
      ...state.history,
      { type: "relation", id: action.id, before: relation.assessment },
    ],
    notice: "关系已更新：连线、标签与解释同步，材料原文保持不变。",
  };
}
