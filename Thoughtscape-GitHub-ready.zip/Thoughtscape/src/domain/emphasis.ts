import type {
  Claim,
  Concept,
  MapPreview,
  Relation,
  StanceFilter,
} from "../types/knowledge";
import { neighborhood, relationStances } from "./exploration.ts";

// Preview is transient. It never changes the saved selection, topology or viewport.
export function mapEmphasis(
  concepts: Concept[],
  relations: Relation[],
  stance: StanceFilter,
  spotlight: Set<string> | null,
  activeIds: Set<string>,
  preview: MapPreview | null,
  claimIndex?: Record<string, Claim>,
) {
  const previewRelation =
    preview?.type === "relation"
      ? relations.find((r) => r.id === preview.id)
      : undefined;
  const previewIds =
    preview?.type === "concept"
      ? neighborhood(preview.id, relations)
      : previewRelation
        ? new Set([previewRelation.sourceId, previewRelation.targetId])
        : preview?.type === "issue"
          ? new Set(["issue"])
          : null;
  const focus = previewIds ?? spotlight;
  const matchingEdges = new Set(
    relations
      .filter(
        (r) =>
          stance === "all" || relationStances(r, claimIndex).includes(stance),
      )
      .map((r) => r.id),
  );
  const bridges = new Set(
    relations
      .filter((r) => matchingEdges.has(r.id))
      .flatMap((r) => [r.sourceId, r.targetId]),
  );
  const nodes = new Map(
    ["issue", ...concepts.map((c) => c.id)].map((id) => {
      const concept = concepts.find((c) => c.id === id),
        chosen = activeIds.has(id),
        related = !!focus?.has(id);
      const matches =
        stance === "all" || !concept || concept.stanceIds.includes(stance);
      const bridge = stance !== "all" && !matches && bridges.has(id);
      return [
        id,
        {
          previewed: preview?.type !== "relation" && preview?.id === id,
          related: related && !chosen,
          bridge,
          muted: !chosen && (focus ? !related : !matches && !bridge),
          overview: !focus && !chosen,
        },
      ];
    }),
  );
  const edges = new Map(
    relations.map((r) => {
      const chosen = activeIds.has(r.sourceId) && activeIds.has(r.targetId);
      const inFocus = !!focus?.has(r.sourceId) && !!focus?.has(r.targetId);
      const previewed =
        previewRelation?.id === r.id ||
        (preview?.type === "concept" &&
          (r.sourceId === preview.id || r.targetId === preview.id));
      return [
        r.id,
        {
          active: chosen || inFocus || previewed,
          muted:
            !chosen &&
            !previewed &&
            (focus ? !inFocus : !matchingEdges.has(r.id)),
          previewed,
        },
      ];
    }),
  );
  return { nodes, edges, previewIds, matchingEdges };
}
