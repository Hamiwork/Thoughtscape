import type { Concept, Relation, StanceId } from "../types/knowledge";
import { claimById } from "../data/demo.ts";
export function incidentRelations(id: string, relations: Relation[]) {
  return relations.filter((r) => r.sourceId === id || r.targetId === id);
}
export function neighborIds(id: string, relations: Relation[]) {
  return [
    ...new Set(
      incidentRelations(id, relations).map((r) =>
        r.sourceId === id ? r.targetId : r.sourceId,
      ),
    ),
  ];
}
export function neighborhood(
  id: string,
  relations: Relation[],
  depth = 1,
): Set<string> {
  const seen = new Set([id]);
  let frontier = [id];
  for (let i = 0; i < depth; i++) {
    const next = frontier
      .flatMap((x) => neighborIds(x, relations))
      .filter((x) => !seen.has(x));
    next.forEach((x) => seen.add(x));
    frontier = next;
  }
  return seen;
}
export function relationStances(
  relation: Relation,
  claimIndex = claimById,
): StanceId[] {
  return [
    ...new Set(
      relation.claimIds.flatMap((id) =>
        claimIndex[id] ? [claimIndex[id].stanceId] : [],
      ),
    ),
  ];
}
export function isCrossStance(relation: Relation, claimIndex = claimById) {
  const s = relationStances(relation, claimIndex);
  return s.includes("automation") && s.includes("challenge");
}
export function stanceMatches(concept: Concept, stance: StanceId | "all") {
  return stance === "all" || concept.stanceIds.includes(stance);
}
