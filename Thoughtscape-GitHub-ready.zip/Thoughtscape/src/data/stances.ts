import type { StanceId } from "../types/knowledge";
// Argumentative perspectives, independent of concept types and relation semantics.
export const stances: Record<
  StanceId,
  {
    label: string;
    short: string;
    symbol: string;
    color: string;
    description: string;
  }
> = {
  automation: {
    label: "支持自动化",
    short: "支持",
    symbol: "＋",
    color: "#6b7868",
    description: "从可用容量、速度和成本理解自动化的价值。",
  },
  challenge: {
    label: "质疑过度自动化",
    short: "质疑",
    symbol: "−",
    color: "#802b38",
    description: "检查失败、错误承诺与无法找到人工时的代价。",
  },
  conditional: {
    label: "条件与权衡",
    short: "条件",
    symbol: "◇",
    color: "#957a4f",
    description: "比较任务、风险与交接条件，而非预设站队。",
  },
};
