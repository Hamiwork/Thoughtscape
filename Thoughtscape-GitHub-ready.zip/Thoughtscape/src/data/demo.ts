import { concepts, claims, issue } from "./entities.ts";
import { evidence as rawEvidence, sources } from "./sources.ts";
import { relations } from "./relations.ts";
export { concepts, claims, issue, sources, relations };
export { dataNotice } from "./sources.ts";
export { relationMeta } from "./relations.ts";
export { stances } from "./stances.ts";
export const conceptById = Object.fromEntries(concepts.map((c) => [c.id, c]));
export const claimById = Object.fromEntries(claims.map((c) => [c.id, c]));
export const sourceById = Object.fromEntries(sources.map((s) => [s.id, s]));
export const evidence = rawEvidence.map((e) => ({
  ...e,
  conceptIds: concepts
    .filter((c) => c.evidenceIds.includes(e.id))
    .map((c) => c.id),
  relationIds: relations
    .filter((r) => r.evidenceIds.includes(e.id))
    .map((r) => r.id),
}));
export const evidenceById = Object.fromEntries(evidence.map((e) => [e.id, e]));
