import type { MapNode, Concept } from "../types/knowledge";
import { issue as demoIssue } from "./entities.ts";
export function mapNodes(
  concepts: Concept[],
  issue = demoIssue,
  issuePosition = { x: 600, y: 210 },
): MapNode[] {
  return [
    {
      id: issue.id,
      type: "knowledge",
      position: issuePosition,
      data: {
        name: issue.name,
        number: "001",
        objectType: "issue",
        level: "primary",
        stanceIds: [],
        muted: false,
        selected: false,
        related: false,
      },
      ariaLabel: `${issue.name}，点击探索议题`,
    },
    ...concepts.map((c, index) => ({
      id: c.id,
      type: "knowledge" as const,
      position: c.position,
      data: {
        name: c.name,
        number: String(index + 1).padStart(2, "0"),
        objectType: c.type,
        level: c.level,
        stanceIds: c.stanceIds,
        muted: false,
        selected: false,
        related: false,
      },
      ariaLabel: `${c.name}，点击探索关联`,
    })),
  ];
}
