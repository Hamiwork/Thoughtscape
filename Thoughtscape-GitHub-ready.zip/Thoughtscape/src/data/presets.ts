import type { KnowledgeDataset } from "../types/knowledge";
import * as demo from "./demo.ts";
import { normalizeGeneratedGraph } from "../domain/generatedGraph.ts";
import writing from "./presets/writing.json" with { type: "json" };
import remote from "./presets/remote.json" with { type: "json" };
import workweek from "./presets/workweek.json" with { type: "json" };
import mobility from "./presets/mobility.json" with { type: "json" };

export interface PresetQuestion {
  id: string;
  name: string;
  question: string;
  searchTerms: string[];
  data: KnowledgeDataset;
}
function curated(raw: unknown, question: string): KnowledgeDataset {
  // Shared contract validation and layout run locally; no AI or network call.
  const normalized = normalizeGeneratedGraph(raw, question, "curated-preset");
  return {
    ...normalized,
    mode: "demo",
    generation: undefined,
    dataNotice: "演示假设，待核实",
    relations: normalized.relations.map((r) => ({
      ...r,
      verification: "demo-hypothesis",
      assessment: { ...r.assessment, origin: "demo" },
    })),
  };
}
const seeds = [
  {
    id: "writing",
    name: "AI 辅助写作",
    question: "大学应该允许学生使用 AI 辅助写作吗？",
    searchTerms: ["写作", "大学", "学生", "教育", "学习"],
    raw: writing,
  },
  {
    id: "remote",
    name: "远程办公",
    question: "远程办公能提高效率，还是会削弱团队协作？",
    searchTerms: ["远程", "居家", "协作", "办公"],
    raw: remote,
  },
  {
    id: "workweek",
    name: "四天工作制",
    question: "四天工作制能提升工作质量，还是会压缩服务能力？",
    searchTerms: ["四天", "工作制", "工时", "排班"],
    raw: workweek,
  },
  {
    id: "mobility",
    name: "城市交通",
    question: "缓解城市拥堵，应该优先公共交通还是拓宽道路？",
    searchTerms: ["交通", "公交", "拥堵", "扩路", "道路", "通勤"],
    raw: mobility,
  },
];
export const presetQuestions: PresetQuestion[] = [
  {
    id: "customer",
    name: "AI 客服",
    question: demo.issue.question,
    searchTerms: ["客服", "人工", "投诉", "自动化"],
    data: {
      mode: "demo",
      issue: demo.issue,
      concepts: demo.concepts,
      relations: demo.relations,
      claims: demo.claims,
      evidence: demo.evidence,
      sources: demo.sources,
      stances: demo.stances,
      dataNotice: demo.dataNotice,
    },
  },
  ...seeds.map(({ raw, ...seed }) => ({
    ...seed,
    data: curated(raw, seed.question),
  })),
];
const clean = (text: string) =>
  text.toLowerCase().replace(/[\s，。？！、？?!：:；;“”「」]/g, "");
export function matchingPresets(query: string) {
  const q = clean(query);
  if (!q) return presetQuestions;
  const exact = presetQuestions.find(
    (p) => clean(p.question) === q || clean(p.name) === q,
  );
  if (exact) return [exact];
  return presetQuestions.filter(
    (p) =>
      clean(p.question).includes(q) ||
      p.searchTerms.some((t) => q.includes(clean(t)) || clean(t).includes(q)),
  );
}
